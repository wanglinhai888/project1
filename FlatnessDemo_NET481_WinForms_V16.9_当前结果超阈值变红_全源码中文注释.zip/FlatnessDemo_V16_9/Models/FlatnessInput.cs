// ============================================================================
// 文件：FlatnessInput.cs
// 作用：保存一片瓷砖的命名测点值，例如 A、A1、DA、CE、C1 等。
// 设计：使用不区分大小写的字典，算法可以按点名直接读取。
// ============================================================================
using System;
using System.Collections.Generic;

namespace FlatnessDemo.Models
{
    /// <summary>
    /// Planar 平整度算法的命名测点输入。
    /// </summary>
    public sealed class FlatnessInput
    {
        // 实际数据容器。StringComparer.OrdinalIgnoreCase 避免大小写造成同一点重复。
        private readonly Dictionary<string, double> _points =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

        /// <summary>只读方式暴露全部测点，防止外部替换内部字典。</summary>
        public IReadOnlyDictionary<string, double> Points { get { return _points; } }

        /// <summary>
        /// 按测点名读写数据。读取不存在的点时返回 0，避免 Demo 因缺点直接异常。
        /// </summary>
        public double this[string name]
        {
            get
            {
                double value;
                return _points.TryGetValue(name, out value) ? value : 0.0;
            }
            set { _points[name] = value; }
        }

        /// <summary>
        /// 深复制当前测点集合，便于后续算法在不修改原始输入的前提下处理数据。
        /// </summary>
        public FlatnessInput Clone()
        {
            var copy = new FlatnessInput();
            foreach (var kv in _points)
                copy[kv.Key] = kv.Value;
            return copy;
        }
    }
}
