// ============================================================================
// 文件：HistoryItem.cs
// 作用：描述历史记录中一片瓷砖的结果数据。
// 备注：当前 Demo 的 DataGridView 直接插入行，本模型为后续数据库/绑定模式预留。
// ============================================================================
using System;

namespace FlatnessDemo.Models
{
    /// <summary>
    /// 单片瓷砖历史结果记录。
    /// </summary>
    public sealed class HistoryItem
    {
        public int No { get; set; }             // 流水序号
        public DateTime Time { get; set; }      // 检测时间
        public double SVE { get; set; }
        public double BAR { get; set; }
        public double ANPlus { get; set; }
        public double ANMinus { get; set; }
        public double LXPlus { get; set; }
        public double LXMinus { get; set; }
        public double LYPlus { get; set; }
        public double LYMinus { get; set; }
        public double CEPlus { get; set; }
        public double CEMinus { get; set; }
        public string Grade { get; set; }       // 一级品/二级品/三级品/不合格
    }
}
