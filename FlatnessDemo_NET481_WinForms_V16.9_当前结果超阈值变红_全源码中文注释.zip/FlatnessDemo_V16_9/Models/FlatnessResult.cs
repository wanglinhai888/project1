// ============================================================================
// 文件：FlatnessResult.cs
// 作用：统一承载 Planar 平整度算法的输出结果。
// 说明：Plus 表示正向最大值，Minus 表示负向最小值；BAR/SVE/RUL 为独立指标。
// ============================================================================
namespace FlatnessDemo.Models
{
    /// <summary>
    /// 一片瓷砖的平整度计算结果 DTO。
    /// </summary>
    public sealed class FlatnessResult
    {
        public double SVE { get; set; }     // 四角/整体扭曲相关指标
        public double BAR { get; set; }     // 四边中心与相邻点 8 个差值的最大绝对值
        public double RUL { get; set; }     // 当前 Demo 尚未确认最终公式

        public double ANPlus { get; set; }  // AN 正向最大值
        public double ANMinus { get; set; } // AN 负向最小值

        public double LXPlus { get; set; }  // X 方向正向结果
        public double LXMinus { get; set; } // X 方向负向结果

        public double LYPlus { get; set; }  // Y 方向正向结果
        public double LYMinus { get; set; } // Y 方向负向结果

        public double CEPlus { get; set; }  // 中心相关正向结果
        public double CEMinus { get; set; } // 中心相关负向结果
    }
}
