// ============================================================================
// 文件：CompensationSettings.cs
// 作用：定义各平整度指标的比例系数和补偿偏移。
// 公式：最终值 = 原始算法值 × Ratio + Offset。
// ============================================================================
using System.Collections.Generic;

namespace FlatnessDemo.Models
{
    /// <summary>
    /// 单个指标的比例与补偿参数。
    /// </summary>
    public sealed class CompensationItem
    {
        /// <summary>指标名称。</summary>
        public string Metric { get; set; }

        /// <summary>乘法比例系数，默认 1.0。</summary>
        public double Ratio { get; set; }

        /// <summary>加法补偿值，默认 0.0。</summary>
        public double Offset { get; set; }
    }

    /// <summary>
    /// 默认比例与补偿参数工厂。
    /// </summary>
    public static class CompensationSettings
    {
        /// <summary>
        /// 为所有当前支持的平整度指标创建默认参数。
        /// </summary>
        public static List<CompensationItem> CreateDefaults()
        {
            var names = new[] { "AN+", "AN-", "LX+", "LX-", "LY+", "LY-", "CE+", "CE-", "SVE", "BAR", "RUL" };
            var list = new List<CompensationItem>();

            foreach (var n in names)
                list.Add(new CompensationItem { Metric = n, Ratio = 1.0, Offset = 0.0 });

            return list;
        }
    }
}
