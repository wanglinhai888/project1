// ============================================================================
// 文件：GradeSettings.cs
// 作用：定义每个平整度指标的一级/二级/三级阈值，以及 Demo 默认阈值。
// 规则：最终等级按最差指标决定；界面“超阈值变红”只使用 Grade1 作为告警线。
// ============================================================================
using System.Collections.Generic;

namespace FlatnessDemo.Models
{
    /// <summary>
    /// 单个平整度指标的三级质量阈值。
    /// </summary>
    public sealed class GradeThreshold
    {
        /// <summary>指标名称，例如 AN+、BAR、SVE。</summary>
        public string Metric { get; set; }

        /// <summary>一级品允许的最大绝对值。</summary>
        public double Grade1 { get; set; }

        /// <summary>二级品允许的最大绝对值。</summary>
        public double Grade2 { get; set; }

        /// <summary>三级品允许的最大绝对值。</summary>
        public double Grade3 { get; set; }
    }

    /// <summary>
    /// 默认等级阈值工厂。
    /// </summary>
    public static class GradeSettings
    {
        /// <summary>
        /// 创建 Demo 默认阈值。
        /// 正负指标分别配置，便于以后业务上设置不同标准。
        /// </summary>
        public static List<GradeThreshold> CreateDefaults()
        {
            return new List<GradeThreshold>
            {
                T("SVE", 0.50, 0.80, 1.20),
                T("BAR", 0.30, 0.60, 1.00),
                T("AN+", 0.40, 0.70, 1.10),
                T("AN-", 0.40, 0.70, 1.10),
                T("LX+", 0.50, 0.80, 1.20),
                T("LX-", 0.50, 0.80, 1.20),
                T("LY+", 0.50, 0.80, 1.20),
                T("LY-", 0.50, 0.80, 1.20),
                T("CE+", 0.50, 0.80, 1.20),
                T("CE-", 0.50, 0.80, 1.20)
            };
        }

        /// <summary>
        /// 简化默认阈值对象的创建代码。
        /// </summary>
        private static GradeThreshold T(string metric, double g1, double g2, double g3)
        {
            return new GradeThreshold { Metric = metric, Grade1 = g1, Grade2 = g2, Grade3 = g3 };
        }
    }
}
