// ============================================================================
// 文件：SensorCalibrationItem.cs
// 作用：保存单个物理位移传感器的实时值、零点偏移和板补偿参数。
// ============================================================================
namespace FlatnessDemo.Models
{
    /// <summary>
    /// 单个传感器的校准数据。
    /// </summary>
    public sealed class SensorCalibrationItem
    {
        public int SensorIndex { get; set; }          // 原始物理传感器编号
        public double RawValue { get; set; }          // 当前采集到的实时原始值
        public double ZeroOffset { get; set; }        // 一键置零得到的零点偏移
        public double BoardCompensation { get; set; } // 标准板/基准板补偿

        /// <summary>
        /// 应用零点偏移后的实时值；板补偿在业务链路中可按需要继续叠加。
        /// </summary>
        public double ZeroedValue
        {
            get { return RawValue + ZeroOffset; }
        }
    }
}
