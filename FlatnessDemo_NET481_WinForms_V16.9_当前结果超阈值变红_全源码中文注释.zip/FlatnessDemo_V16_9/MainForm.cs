﻿// ============================================================================
// 文件：MainForm.cs
// 作用：平整度 Demo 主窗体。负责页面布局、Tab 页面、模拟刷新、等级判定、历史记录、
//       阈值设置、传感器选择/校准、比例补偿，以及各自定义控件之间的数据协调。
// 原则：算法计算放在 Algorithms；数据模型放在 Models；复杂绘制放在 Controls。
// ============================================================================
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using FlatnessDemo.Algorithms;
using FlatnessDemo.Controls;
using FlatnessDemo.Models;

namespace FlatnessDemo
{
    /// <summary>
    /// 平整度模块主窗口，负责把数据、算法和 UI 控件组织成完整工作流程。
    /// </summary>
    public sealed class MainForm : Form
    {
        // ------------------------------
        // 左侧/右侧核心显示控件
        // ------------------------------
        private readonly PointGridControl _pointGrid = new PointGridControl();
        private readonly Flatness3DControl _surface3D = new Flatness3DControl();
        private readonly SensorSelectionControl _sensorSelection = new SensorSelectionControl();

        private readonly Label _gradeLabel = new Label();
        private readonly Label _statsLabel = new Label();
        private readonly FlatnessResultControl _resultControl = new FlatnessResultControl();
        private readonly Label _clockLabel = new Label();

        // ------------------------------
        // 参数与历史数据表格
        // ------------------------------
        private readonly DataGridView _historyGrid = Theme.CreateGrid();
        private readonly DataGridView _gradeGrid = Theme.CreateGrid();
        private readonly DataGridView _compGrid = Theme.CreateGrid();
        private readonly DataGridView _calibrationGrid = Theme.CreateGrid();

        // ------------------------------
        // 参数输入控件
        // ------------------------------
        private readonly ComboBox _sensorCount = new ComboBox();
        private readonly TextBox _tileLengthTextBox = new TextBox();
        private readonly TextBox _tileWidthTextBox = new TextBox();
        private readonly Label _tileDiagonalValueLabel = new Label();

        // Demo 定时器：模拟连续生产时每隔一段时间刷新一片砖的数据。
        private readonly Timer _timer = new Timer();
        private TableLayoutPanel _calibrationTabLayout;

        // V16.3: 右侧参数 Tab 可折叠。折叠后保留一个独立、完整可见的展开按钮区域，
        // 其余空间全部让给上方 3D 平整度图；同时修复顶部模块按钮和底部展开按钮被固定行高裁切的问题。
        private TableLayoutPanel _rightLayout;
        private Panel _tabsHost;
        private TabControl _tabsControl;
        private Button _toggleTabsButton;
        private bool _tabsCollapsed;

        // ------------------------------
        // 业务参数与运行状态
        // ------------------------------
        private readonly List<GradeThreshold> _gradeSettings = GradeSettings.CreateDefaults();
        private readonly List<CompensationItem> _compSettings = CompensationSettings.CreateDefaults();
        private List<SensorCalibrationItem> _calibrationItems = MockData.CreateCalibration(7);

        private int _currentSensorCount = 7;

        private double _tileLength = 1200.0;
        private double _tileWidth = 600.0;
        private double _tileDiagonal = Math.Sqrt(1200.0 * 1200.0 + 600.0 * 600.0);

        private int _historyNo = 1;
        private int _total = 1258;
        private int _good = 1240;

        /// <summary>
        /// 初始化主窗体、构建界面、绑定默认设置并启动 Demo 数据刷新。
        /// </summary>
        public MainForm()
        {
            Text = "智能拣选系统 - 平整度 Demo";
            WindowState = FormWindowState.Maximized;
            MinimumSize = new Size(1280, 760);
            BackColor = Theme.Panel;
            ForeColor = Theme.Text;
            Font = Theme.Font(9f);

            BuildUi();
            _surface3D.SetTileSize(_tileLength, _tileWidth);
            BindSettings();

            // 将等级设置同步给左下角平整度结果控件。
            // 控件据此把“超过一级阈值”的结果数值直接显示为红色。
            _resultControl.SetThresholds(_gradeSettings);

            RefreshCalibrationGrid();

            _timer.Interval = 1200;
            _timer.Tick += delegate { UpdateMockTile(); };
            _timer.Start();

            UpdateMockTile();
        }

        /// <summary>
        /// 构建主窗体四大区域：标题栏、模块导航、主体内容、底部状态栏。
        /// </summary>
        private void BuildUi()
        {
            var root = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                ColumnCount = 1,
                RowCount = 4,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            Controls.Add(root);

            root.Controls.Add(BuildHeader(), 0, 0);
            root.Controls.Add(BuildModuleTabs(), 0, 1);
            root.Controls.Add(BuildBody(), 0, 2);
            root.Controls.Add(BuildStatus(), 0, 3);
        }

        /// <summary>
        /// 创建顶部标题栏与右上角系统时间。
        /// </summary>
        private Control BuildHeader()
        {
            var p = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Header };
            var title = Theme.Label("智能拣选系统（Intelligent Picking System）V1.0 Demo", 11f, FontStyle.Bold);
            title.Location = new Point(16, 11);
            p.Controls.Add(title);

            _clockLabel.ForeColor = Theme.Text;
            _clockLabel.Font = Theme.Font(10f);
            _clockLabel.AutoSize = true;
            _clockLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _clockLabel.Location = new Point(Width - 220, 12);
            p.Controls.Add(_clockLabel);

            p.Resize += delegate { _clockLabel.Left = p.Width - _clockLabel.Width - 18; };
            return p;
        }

        /// <summary>
        /// 创建模块导航按钮；当前 Demo 固定高亮“平整度”。
        /// </summary>
        private Control BuildModuleTabs()
        {
            var p = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                BackColor = Theme.Nav,
                Padding = new Padding(205, 6, 0, 4),
                WrapContents = false
            };

            string[] names = { "缺陷检测", "尺寸", "平整度", "色号图像", "版面识别" };
            foreach (var name in names)
            {
                var b = Theme.Button(name);
                b.Width = 108;
                b.Height = 32;
                // 固定模块栏以前只有 36px，高 DPI/字体缩放时按钮上下边框会被裁掉。
                // V16.3 给按钮明确的纵向安全边距，不再依赖 FlowLayoutPanel 默认 Margin。
                b.Margin = new Padding(3, 0, 3, 0);
                b.BackColor = name == "平整度" ? Theme.Accent : Theme.Nav;
                p.Controls.Add(b);
            }

            return p;
        }

        /// <summary>
        /// 创建主体两列布局：左侧功能导航，右侧平整度工作区。
        /// </summary>
        private Control BuildBody()
        {
            var body = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 1,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));
            body.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            body.Controls.Add(BuildNav(), 0, 0);
            body.Controls.Add(BuildFlatnessArea(), 1, 0);
            return body;
        }

        /// <summary>
        /// 创建左侧纵向功能按钮区。
        /// </summary>
        private Control BuildNav()
        {
            var nav = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                BackColor = Theme.Nav,
                Padding = new Padding(12, 16, 12, 8),
                WrapContents = false
            };

            string[] names = { "用户登录", "数据维护", "模板加载", "停止检测", "显示缺陷", "系统设置", "检测设置", "一键复位" };
            foreach (var name in names)
            {
                var b = Theme.Button(name);
                b.Width = 170;
                b.Height = 46;
                b.TextAlign = ContentAlignment.MiddleLeft;
                nav.Controls.Add(b);
            }

            return nav;
        }

        /// <summary>
        /// 创建平整度主工作区：测点/结果、3D 图和下方参数 Tab。
        /// </summary>
        private Control BuildFlatnessArea()
        {
            // V16.5：左下 Planar 结果区上调并增高；右侧仍保持独立布局。
            var outer = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                ColumnCount = 2,
                RowCount = 1,
                Padding = new Padding(6)
            };
            outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 48));
            outer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 52));

            var left = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                ColumnCount = 1,
                RowCount = 2,
                Margin = Padding.Empty
            };
            left.RowStyles.Add(new RowStyle(SizeType.Percent, 58));
            left.RowStyles.Add(new RowStyle(SizeType.Percent, 42));
            left.Controls.Add(Wrap(_pointGrid), 0, 0);
            left.Controls.Add(BuildResultPanel(), 0, 1);

            _rightLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                ColumnCount = 1,
                RowCount = 2,
                Margin = Padding.Empty
            };
            // 展开状态：3D 区占 52%，Tab 区占 48%。
            // 折叠状态会动态改为：3D 区占剩余全部空间，Tab 区仅保留 40px 安全按钮带。
            _rightLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 52));
            _rightLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 48));
            _rightLayout.Controls.Add(BuildRightTop(), 0, 0);
            _rightLayout.Controls.Add(BuildTabs(), 0, 1);

            outer.Controls.Add(left, 0, 0);
            outer.Controls.Add(_rightLayout, 1, 0);
            return outer;
        }

        /// <summary>
        /// 创建右侧上半区：当前等级统计和 3D 平整度图。
        /// </summary>
        private Control BuildRightTop()
        {
            var p = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = Theme.Panel,
                Margin = new Padding(3)
            };
            p.RowStyles.Add(new RowStyle(SizeType.Absolute, 104));
            p.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var grade = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel2,
                Padding = new Padding(8),
                ColumnCount = 1,
                RowCount = 2
            };
            grade.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
            grade.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));

            _gradeLabel.Dock = DockStyle.Fill;
            _gradeLabel.TextAlign = ContentAlignment.MiddleCenter;
            _gradeLabel.Font = Theme.Font(22f, FontStyle.Bold);
            _gradeLabel.ForeColor = Color.White;
            _gradeLabel.BackColor = Theme.Good;

            _statsLabel.Dock = DockStyle.Fill;
            _statsLabel.TextAlign = ContentAlignment.MiddleCenter;
            _statsLabel.Font = Theme.Font(9.8f, FontStyle.Bold);
            _statsLabel.ForeColor = Color.WhiteSmoke;
            _statsLabel.BackColor = Theme.Panel2;
            _statsLabel.AutoEllipsis = true;

            grade.Controls.Add(_gradeLabel, 0, 0);
            grade.Controls.Add(_statsLabel, 0, 1);

            p.Controls.Add(grade, 0, 0);
            p.Controls.Add(Wrap(_surface3D), 0, 1);
            return p;
        }

        /// <summary>
        /// 创建左下角 Planar 平整度结果控件容器。
        /// </summary>
        private Control BuildResultPanel()
        {
            var p = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel2,
                Margin = new Padding(3),
                Padding = new Padding(2)
            };

            _resultControl.Dock = DockStyle.Fill;
            p.Controls.Add(_resultControl);
            return p;
        }

        /// <summary>
        /// 创建历史、等级、调整顺序、比例补偿、传感器校准五个 Tab 页面。
        /// </summary>
        private Control BuildTabs()
        {
            _tabsHost = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                // 旧版这里有上下各 3px Margin，折叠行只有 32px 时，
                // 实际 ClientHeight 会小于 29px 按钮高度，导致“展开”按钮下沿被裁切。
                Margin = Padding.Empty,
                Padding = new Padding(3, 0, 3, 2)
            };

            _tabsControl = new CleanTabControl
            {
                Dock = DockStyle.Fill,
                Font = Theme.Font(8.6f, FontStyle.Bold),
                Margin = Padding.Empty,
                DrawMode = TabDrawMode.OwnerDrawFixed,
                SizeMode = TabSizeMode.Fixed,
                ItemSize = new Size(92, 29),
                Padding = new Point(8, 3),
                TabStop = false
            };
            _tabsControl.DrawItem += DrawBlueTab;

            _tabsControl.TabPages.Add(BuildHistoryTab());
            _tabsControl.TabPages.Add(BuildGradeTab());
            _tabsControl.TabPages.Add(BuildSelectionTab());
            _tabsControl.TabPages.Add(BuildCompensationTab());
            _tabsControl.TabPages.Add(BuildCalibrationTab());

            _toggleTabsButton = Theme.Button("收起 ▲");
            _toggleTabsButton.Size = new Size(82, 30);
            _toggleTabsButton.TextAlign = ContentAlignment.MiddleCenter;
            _toggleTabsButton.Font = Theme.Font(8.6f, FontStyle.Bold);
            _toggleTabsButton.TabStop = false;
            _toggleTabsButton.Click += delegate { ToggleTabs(); };

            // 按钮覆盖在 Tab 标题栏右侧，不额外占用一行高度。
            _tabsHost.Controls.Add(_tabsControl);
            _tabsHost.Controls.Add(_toggleTabsButton);
            _toggleTabsButton.BringToFront();

            _tabsHost.Resize += delegate { PositionTabsToggleButton(); };
            PositionTabsToggleButton();

            return _tabsHost;
        }

        /// <summary>
        /// 根据 Tab 容器尺寸定位“收起/展开”按钮，避免被边框或状态栏裁切。
        /// </summary>
        private void PositionTabsToggleButton()
        {
            if (_tabsHost == null || _toggleTabsButton == null)
                return;

            int x = Math.Max(0, _tabsHost.ClientSize.Width - _toggleTabsButton.Width - 7);
            int y;
            if (_tabsCollapsed)
            {
                // 折叠时让按钮在 40px 安全带中垂直居中，避免底部状态栏遮挡。
                y = Math.Max(3, (_tabsHost.ClientSize.Height - _toggleTabsButton.Height) / 2);
            }
            else
            {
                // 展开时仍贴近 Tab 标题栏右上角，但保留 3px 顶边距。
                y = 3;
            }
            _toggleTabsButton.Location = new Point(x, y);
            _toggleTabsButton.BringToFront();
        }

        /// <summary>
        /// 切换参数 Tab 的折叠状态；折叠后把更多高度让给 3D 图。
        /// </summary>
        private void ToggleTabs()
        {
            if (_rightLayout == null || _tabsHost == null || _tabsControl == null || _toggleTabsButton == null)
                return;

            _tabsCollapsed = !_tabsCollapsed;

            _rightLayout.SuspendLayout();
            _tabsHost.SuspendLayout();

            if (_tabsCollapsed)
            {
                // 只保留完整按钮安全带，其余垂直空间全部给 3D 区。
                _tabsControl.Visible = false;
                _rightLayout.RowStyles[0].SizeType = SizeType.Percent;
                _rightLayout.RowStyles[0].Height = 100f;
                _rightLayout.RowStyles[1].SizeType = SizeType.Absolute;
                _rightLayout.RowStyles[1].Height = 40f;
                _toggleTabsButton.Text = "展开 ▼";
            }
            else
            {
                _tabsControl.Visible = true;
                _rightLayout.RowStyles[0].SizeType = SizeType.Percent;
                _rightLayout.RowStyles[0].Height = 52f;
                _rightLayout.RowStyles[1].SizeType = SizeType.Percent;
                _rightLayout.RowStyles[1].Height = 48f;
                _toggleTabsButton.Text = "收起 ▲";
            }

            PositionTabsToggleButton();
            _tabsHost.ResumeLayout(true);
            _rightLayout.ResumeLayout(true);
            _rightLayout.PerformLayout();

            // Flatness3DControl 会根据新的 ClientSize 自动重新 Fit/投影，
            // 因此 Tab 隐藏后，3D 曲面会随控件区域一起明显放大。
            _surface3D.Invalidate();
        }

        /// <summary>
        /// 自绘 Tab 页签，使用项目蓝色主题并避免 Windows 默认焦点虚线。
        /// </summary>
        private void DrawBlueTab(object sender, DrawItemEventArgs e)
        {
            var tabs = (TabControl)sender;
            var rect = e.Bounds;
            bool selected = (e.Index == tabs.SelectedIndex);

            using (var back = new SolidBrush(selected ? Theme.Accent : Theme.Nav))
            using (var border = new Pen(Theme.Border))
            using (var textBrush = new SolidBrush(Color.WhiteSmoke))
            using (var format = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            })
            {
                e.Graphics.FillRectangle(back, rect);
                e.Graphics.DrawRectangle(border, rect.X, rect.Y, rect.Width - 1, rect.Height - 1);
                e.Graphics.DrawString(
                    tabs.TabPages[e.Index].Text,
                    tabs.Font,
                    textBrush,
                    rect,
                    format);
            }
        }

        /// <summary>
        /// 创建历史数据页，并配置结果列。
        /// </summary>
        private TabPage BuildHistoryTab()
        {
            var tab = NewTab("历史数据");
            tab.Controls.Add(_historyGrid);
            _historyGrid.ReadOnly = true;
            _historyGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.DisplayedCells;
            ConfigureCompactGrid(_historyGrid, true);

            AddColumns(_historyGrid, "序号", "时间", "SVE", "BAR", "AN+", "AN-", "LX+", "LX-", "LY+", "LY-", "CE+", "CE-", "等级");
            return tab;
        }

        /// <summary>
        /// 创建等级设置页，包括各指标三级阈值和瓷砖规格。
        /// </summary>
        private TabPage BuildGradeTab()
        {
            var tab = NewTab("等级设置");

            AddColumns(_gradeGrid, "指标", "一级品（可改）", "二级品（可改）", "三级品（可改）");
            ConfigureSettingsGrid(_gradeGrid);
            StyleReadOnlyColumns(_gradeGrid, 0);
            StyleEditableColumns(_gradeGrid, 1, 2, 3);

            // 等级页专用紧凑高度：10项必须全部显示，同时给瓷砖规格留出固定区域。
            _gradeGrid.RowTemplate.Height = 20;
            _gradeGrid.ColumnHeadersHeight = 25;
            _gradeGrid.DefaultCellStyle.Font = Theme.Font(8.1f);
            _gradeGrid.ColumnHeadersDefaultCellStyle.Font = Theme.Font(8.1f, FontStyle.Bold);

            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(8, 6, 8, 8),
                Margin = Padding.Empty,
                AutoScroll = true
            };

            // 25表头 + 10×20数据行 + 少量边界 = 229px
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 229));
            // 瓷砖规格固定 96px，保证输入框和按钮始终完整可见。
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 96));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            _gradeGrid.Dock = DockStyle.Fill;
            _gradeGrid.Margin = Padding.Empty;

            layout.Controls.Add(_gradeGrid, 0, 0);
            layout.Controls.Add(BuildTileSpecificationPanel(), 0, 1);

            tab.Controls.Add(layout);
            return tab;
        }


        /// <summary>
        /// 创建瓷砖长度、宽度、对角线显示及保存按钮区域。
        /// </summary>
        private Control BuildTileSpecificationPanel()
        {
            var panel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel2,
                ColumnCount = 4,
                RowCount = 2,
                Margin = new Padding(0, 6, 0, 0),
                Padding = new Padding(10, 5, 10, 6)
            };

            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19));

            panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
            panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var title = new Label
            {
                Text = "瓷砖规格（输入长度和宽度，对角线自动计算）",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Theme.Text,
                BackColor = Color.Transparent,
                Font = Theme.Font(8.8f, FontStyle.Bold)
            };

            panel.Controls.Add(title, 0, 0);
            panel.SetColumnSpan(title, 4);

            ConfigureTileInput(_tileLengthTextBox, _tileLength);
            ConfigureTileInput(_tileWidthTextBox, _tileWidth);

            _tileLengthTextBox.TextChanged += delegate { UpdateTileDiagonalPreview(); };
            _tileWidthTextBox.TextChanged += delegate { UpdateTileDiagonalPreview(); };

            panel.Controls.Add(BuildSpecInputBlock("长度", _tileLengthTextBox, "mm"), 0, 1);
            panel.Controls.Add(BuildSpecInputBlock("宽度", _tileWidthTextBox, "mm"), 1, 1);

            var diagonal = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel2,
                ColumnCount = 1,
                RowCount = 2,
                Margin = new Padding(5, 1, 5, 1)
            };
            diagonal.RowStyles.Add(new RowStyle(SizeType.Absolute, 18));
            diagonal.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var diagonalTitle = new Label
            {
                Text = "对角线（自动）",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.BottomCenter,
                ForeColor = Theme.Muted,
                BackColor = Color.Transparent,
                Font = Theme.Font(7.8f)
            };

            _tileDiagonalValueLabel.Dock = DockStyle.Fill;
            _tileDiagonalValueLabel.TextAlign = ContentAlignment.MiddleCenter;
            _tileDiagonalValueLabel.ForeColor = Color.WhiteSmoke;
            _tileDiagonalValueLabel.BackColor = Color.FromArgb(18, 59, 91);
            _tileDiagonalValueLabel.BorderStyle = BorderStyle.FixedSingle;
            _tileDiagonalValueLabel.Font = Theme.Font(10f, FontStyle.Bold);
            _tileDiagonalValueLabel.Margin = new Padding(2, 2, 2, 4);

            diagonal.Controls.Add(diagonalTitle, 0, 0);
            diagonal.Controls.Add(_tileDiagonalValueLabel, 0, 1);
            panel.Controls.Add(diagonal, 2, 1);

            var save = Theme.Button("保存设置");
            save.Dock = DockStyle.Fill;
            save.Margin = new Padding(7, 20, 0, 7);
            save.Click += delegate { ReadGradeSettings(); };
            panel.Controls.Add(save, 3, 1);

            UpdateTileDiagonalPreview();
            return panel;
        }

        /// <summary>
        /// 创建规格输入块，统一标签、文本框和单位排版。
        /// </summary>
        private Control BuildSpecInputBlock(string label, TextBox textBox, string unit)
        {
            var host = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel2,
                ColumnCount = 1,
                RowCount = 2,
                Margin = new Padding(5, 1, 5, 1)
            };

            host.RowStyles.Add(new RowStyle(SizeType.Absolute, 18));
            host.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var title = new Label
            {
                Text = label + "（" + unit + "）",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.BottomCenter,
                ForeColor = Theme.Muted,
                BackColor = Color.Transparent,
                Font = Theme.Font(7.8f)
            };

            host.Controls.Add(title, 0, 0);
            host.Controls.Add(textBox, 0, 1);
            return host;
        }

        /// <summary>
        /// 创建通用“标签 + 输入框 + 单位”行。
        /// </summary>
        private Control BuildLabeledInput(string label, TextBox textBox, string unit)
        {
            var host = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel2,
                ColumnCount = 3,
                RowCount = 1,
                Margin = new Padding(4, 0, 4, 0)
            };

            host.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 34));
            host.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            host.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 28));

            var left = new Label
            {
                Text = label,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight,
                ForeColor = Theme.Text,
                BackColor = Color.Transparent,
                Font = Theme.Font(8.5f, FontStyle.Bold)
            };

            var right = new Label
            {
                Text = unit,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                ForeColor = Theme.Muted,
                BackColor = Color.Transparent,
                Font = Theme.Font(8f)
            };

            host.Controls.Add(left, 0, 0);
            host.Controls.Add(textBox, 1, 0);
            host.Controls.Add(right, 2, 0);
            return host;
        }

        /// <summary>
        /// 初始化瓷砖规格输入框的外观和默认值。
        /// </summary>
        private void ConfigureTileInput(TextBox textBox, double value)
        {
            textBox.Dock = DockStyle.Fill;
            textBox.TextAlign = HorizontalAlignment.Center;
            textBox.Text = value.ToString("0.00");
            textBox.BackColor = Color.FromArgb(226, 238, 247);
            textBox.ForeColor = Color.FromArgb(17, 48, 72);
            textBox.BorderStyle = BorderStyle.FixedSingle;
            textBox.Font = Theme.Font(10f, FontStyle.Bold);
            textBox.Margin = new Padding(2, 2, 2, 4);
        }

        /// <summary>
        /// 根据当前长度和宽度即时计算对角线预览值。
        /// </summary>
        private void UpdateTileDiagonalPreview()
        {
            double length;
            double width;

            bool okLength = double.TryParse(_tileLengthTextBox.Text, out length) && length > 0;
            bool okWidth = double.TryParse(_tileWidthTextBox.Text, out width) && width > 0;

            if (!okLength || !okWidth)
            {
                _tileDiagonalValueLabel.Text = "-- mm";
                _tileDiagonalValueLabel.ForeColor = Theme.Bad;
                return;
            }

            double diagonal = Math.Sqrt(length * length + width * width);
            _tileDiagonalValueLabel.Text = diagonal.ToString("0.00") + " mm";
            _tileDiagonalValueLabel.ForeColor = Color.WhiteSmoke;

            // 长宽修改时，3D下方XY坐标同步使用真实mm范围。
            _surface3D.SetTileSize(length, width);
        }

        /// <summary>
        /// 创建物理传感器选择/调整顺序页面。
        /// </summary>
        private TabPage BuildSelectionTab()
        {
            var tab = NewTab("调整顺序");
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 2,
                BackColor = Theme.Panel,
                Padding = new Padding(6, 4, 6, 6),
                Margin = Padding.Empty
            };
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

            var top = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                Padding = new Padding(6, 6, 0, 0),
                Margin = Padding.Empty,
                WrapContents = false
            };
            top.Controls.Add(Theme.Label("传感器数量：", 9f, FontStyle.Bold));

            _sensorCount.DropDownStyle = ComboBoxStyle.DropDownList;
            _sensorCount.Width = 78;
            _sensorCount.Items.AddRange(new object[] { 5, 7, 9, 11 });
            _sensorCount.SelectedItem = _currentSensorCount;
            _sensorCount.SelectedIndexChanged += delegate
            {
                if (_sensorCount.SelectedItem != null)
                    SetSensorCount(Convert.ToInt32(_sensorCount.SelectedItem));
            };
            top.Controls.Add(_sensorCount);

            // V16.8：调整顺序页使用可滚动宿主。
            // 小窗口/低分辨率下不会再让“算法取点”和网格相互覆盖。
            var scrollHost = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel,
                AutoScroll = true,
                Margin = Padding.Empty,
                Padding = Padding.Empty
            };
            _sensorSelection.Dock = DockStyle.Top;
            _sensorSelection.Height = 410;
            _sensorSelection.MinimumSize = new Size(440, 410);
            scrollHost.Controls.Add(_sensorSelection);

            layout.Controls.Add(top, 0, 0);
            layout.Controls.Add(scrollHost, 0, 1);
            tab.Controls.Add(layout);
            return tab;
        }

        /// <summary>
        /// 创建比例与补偿设置页；底部操作按钮固定可见。
        /// </summary>
        private TabPage BuildCompensationTab()
        {
            var tab = NewTab("比例与补偿");

            AddColumns(_compGrid, "指标", "比例（可输入）", "补偿（可输入）");
            ConfigureSettingsGrid(_compGrid);
            StyleReadOnlyColumns(_compGrid, 0);
            StyleEditableColumns(_compGrid, 1, 2);

            var save = Theme.Button("保存设置");
            save.Width = 110;
            save.Click += delegate { ReadCompensationSettings(); };

            tab.Controls.Add(BuildTopAlignedGridArea(_compGrid, 11, save));
            return tab;
        }

        /// <summary>
        /// 创建传感器校准页；支持不同传感器数量并保持按钮可见。
        /// </summary>
        private TabPage BuildCalibrationTab()
        {
            var tab = NewTab("传感器校准");

            AddColumns(_calibrationGrid, "传感器", "实时值", "校准值", "板补偿（可输入）");
            ConfigureSettingsGrid(_calibrationGrid);
            StyleReadOnlyColumns(_calibrationGrid, 0, 1, 2);
            StyleEditableColumns(_calibrationGrid, 3);

            _calibrationGrid.CellEndEdit += delegate(object sender, DataGridViewCellEventArgs e)
            {
                if (e.RowIndex >= 0 && e.ColumnIndex == 3)
                    UpdateBoardCompensationFromRow(e.RowIndex);
            };

            var calibrate = Theme.Button("一键校准");
            calibrate.Width = 105;
            calibrate.Click += delegate { CalibrateZero(); };

            var save = Theme.Button("保存板补偿");
            save.Width = 120;
            save.Click += delegate { ReadBoardCompensation(); };

            _calibrationTabLayout = BuildTopAlignedGridArea(_calibrationGrid, _currentSensorCount, calibrate, save);
            tab.Controls.Add(_calibrationTabLayout);
            return tab;
        }

        /// <summary>
        /// 创建主窗体最底部运行状态条。
        /// </summary>
        private Control BuildStatus()
        {
            var p = new Panel { Dock = DockStyle.Fill, BackColor = Theme.Header };
            var label = Theme.Label("当前用户：技术员    │    软件状态：Demo    │    设备状态：Mock正常    │    存储状态：99.24%    │    检测耗时：28 ms", 8.5f);
            label.Location = new Point(16, 7);
            p.Controls.Add(label);
            return p;
        }

        /// <summary>
        /// 把控件放入统一边距的 Panel，减少重复布局代码。
        /// </summary>
        private Panel Wrap(Control child)
        {
            var p = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Theme.Panel2,
                Margin = new Padding(3),
                Padding = new Padding(2)
            };
            child.Dock = DockStyle.Fill;
            p.Controls.Add(child);
            return p;
        }

        /// <summary>
        /// 创建统一背景色和内边距的 TabPage。
        /// </summary>
        private TabPage NewTab(string name)
        {
            return new TabPage(name) { BackColor = Theme.Panel, ForeColor = Theme.Text, Padding = new Padding(4) };
        }

        /// <summary>
        /// 创建“上方表格 + 下方固定按钮栏”的通用设置页布局。
        /// </summary>
        private TableLayoutPanel BuildTopAlignedGridArea(DataGridView grid, int visibleRows, params Button[] buttons)
        {
            // V16.8：设置页统一为“可滚动表格 + 固定底部按钮栏”。
            // 不再用“行数 × 固定行高”去撑页面，因此按钮永远不会被挤到 Tab 可视区之外。
            var layout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1,
                BackColor = Theme.Panel,
                Padding = new Padding(8, 6, 8, 8),
                Margin = Padding.Empty
            };

            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 46));

            grid.Dock = DockStyle.Fill;
            grid.Margin = Padding.Empty;
            grid.ScrollBars = ScrollBars.Both;

            var actions = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                WrapContents = false,
                BackColor = Theme.Panel,
                Padding = new Padding(4, 7, 4, 5),
                Margin = Padding.Empty,
                AutoScroll = false
            };

            foreach (var button in buttons)
            {
                button.Height = 30;
                button.Margin = new Padding(6, 0, 0, 0);
                button.TabStop = false;
                actions.Controls.Add(button);
            }

            layout.Controls.Add(grid, 0, 0);
            layout.Controls.Add(actions, 0, 1);
            return layout;
        }

        /// <summary>
        /// 根据期望可见行数估算设置表格高度。
        /// </summary>
        private static int GetSettingsGridHeight(int rowCount)
        {
            return 30 + Math.Max(1, rowCount) * 25 + 4;
        }

        /// <summary>
        /// 配置紧凑型表格的滚动、行高和边框行为。
        /// </summary>
        private static void ConfigureCompactGrid(DataGridView grid, bool allowScroll)
        {
            grid.RowTemplate.Height = 25;
            grid.ColumnHeadersHeight = 28;
            grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            grid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            grid.AllowUserToResizeColumns = true;
            grid.ScrollBars = allowScroll ? ScrollBars.Both : ScrollBars.None;
            grid.DefaultCellStyle.Font = Theme.Font(8.5f);
            grid.ColumnHeadersDefaultCellStyle.Font = Theme.Font(8.5f, FontStyle.Bold);
        }

        /// <summary>
        /// 配置参数设置表的基础编辑样式。
        /// </summary>
        private static void ConfigureSettingsGrid(DataGridView grid)
        {
            ConfigureCompactGrid(grid, true);
            grid.EditMode = DataGridViewEditMode.EditOnEnter;
            grid.MultiSelect = false;
            grid.AllowUserToOrderColumns = false;
            grid.AllowUserToResizeRows = false;
            grid.SelectionMode = DataGridViewSelectionMode.CellSelect;
        }

        /// <summary>
        /// 把指定列标记为只读并使用深色背景。
        /// </summary>
        private static void StyleReadOnlyColumns(DataGridView grid, params int[] columns)
        {
            foreach (int index in columns)
            {
                if (index < 0 || index >= grid.Columns.Count) continue;
                var col = grid.Columns[index];
                col.ReadOnly = true;
                col.DefaultCellStyle.BackColor = Theme.Panel2;
                col.DefaultCellStyle.ForeColor = Theme.Text;
                col.DefaultCellStyle.SelectionBackColor = Theme.Panel2;
                col.DefaultCellStyle.SelectionForeColor = Theme.Text;
            }
        }

        /// <summary>
        /// 把指定列标记为可编辑并使用浅色背景突出输入区域。
        /// </summary>
        private static void StyleEditableColumns(DataGridView grid, params int[] columns)
        {
            var inputBack = Color.FromArgb(226, 238, 247);
            var inputFore = Color.FromArgb(17, 48, 72);

            foreach (int index in columns)
            {
                if (index < 0 || index >= grid.Columns.Count) continue;
                var col = grid.Columns[index];
                col.ReadOnly = false;
                col.DefaultCellStyle.BackColor = inputBack;
                col.DefaultCellStyle.ForeColor = inputFore;
                col.DefaultCellStyle.SelectionBackColor = Color.White;
                col.DefaultCellStyle.SelectionForeColor = inputFore;
            }
        }

        /// <summary>
        /// 按给定名称批量创建 DataGridView 文本列。
        /// </summary>
        private static void AddColumns(DataGridView grid, params string[] names)
        {
            grid.Columns.Clear();
            foreach (var n in names)
                grid.Columns.Add(n, n);
        }

        /// <summary>
        /// 把默认等级阈值、比例补偿等模型数据填充到各设置表格。
        /// </summary>
        private void BindSettings()
        {
            _gradeGrid.Rows.Clear();
            foreach (var x in _gradeSettings)
                _gradeGrid.Rows.Add(
                    x.Metric,
                    x.Grade1.ToString("0.00"),
                    x.Grade2.ToString("0.00"),
                    x.Grade3.ToString("0.00"));

            _compGrid.Rows.Clear();
            foreach (var x in _compSettings)
                _compGrid.Rows.Add(
                    x.Metric,
                    x.Ratio.ToString("0.00"),
                    x.Offset.ToString("0.00"));
        }

        /// <summary>
        /// 模拟处理一片新砖：生成数据→算法→补偿→等级→刷新界面→写历史。
        /// </summary>
        private void UpdateMockTile()
        {
            var input = MockData.CreateInput();
            _pointGrid.SetInput(input);
            _surface3D.SetSurface(MockData.CreateSurface(input));

            var raw = FlatnessAlgorithms.Calculate(input);
            var result = FlatnessAlgorithms.ApplyCompensation(raw, _compSettings);
            var grade = EvaluateGrade(result);

            _gradeLabel.Text = grade == "一级品" ? "良 品" : grade;
            _gradeLabel.BackColor = grade == "一级品" ? Theme.Good :
                grade == "二级品" ? Theme.Warning :
                grade == "三级品" ? Color.DarkOrange : Theme.Bad;

            _total++;
            if (grade != "不合格") _good++;

            _statsLabel.Text =
                "瓷砖通过总数：" + _total +
                "     合格率：" + (_good * 100.0 / _total).ToString("0.00") + "%" +
                "     当前等级：" + grade;

            _resultControl.SetResult(result);

            AddHistory(result, grade);
            _clockLabel.Text = DateTime.Now.ToString("yyyy/M/d HH:mm:ss");

            // 模拟传感器当前原始值变化
            foreach (var item in _calibrationItems)
                item.RawValue = Math.Round(item.RawValue + (new Random(Guid.NewGuid().GetHashCode()).NextDouble() - 0.5) * 0.015, 3);
            RefreshCalibrationGrid();
        }

        /// <summary>
        /// 把当前砖结果插入历史表首行，并按阈值刷新告警样式。
        /// </summary>
        private void AddHistory(FlatnessResult r, string grade)
        {
            _historyGrid.Rows.Insert(0,
                _historyNo++,
                DateTime.Now.ToString("HH:mm:ss"),
                r.SVE.ToString("0.00"),
                r.BAR.ToString("0.00"),
                r.ANPlus.ToString("0.00"),
                r.ANMinus.ToString("0.00"),
                r.LXPlus.ToString("0.00"),
                r.LXMinus.ToString("0.00"),
                r.LYPlus.ToString("0.00"),
                r.LYMinus.ToString("0.00"),
                r.CEPlus.ToString("0.00"),
                r.CEMinus.ToString("0.00"),
                grade);

            if (_historyGrid.Rows.Count > 0)
                StyleHistoryRowByThreshold(_historyGrid.Rows[0]);

            while (_historyGrid.Rows.Count > 100)
                _historyGrid.Rows.RemoveAt(_historyGrid.Rows.Count - 1);
        }

        /// <summary>
        /// 按一级阈值检查历史行；任一数值超过阈值时该单元格统一红色告警。
        /// 未超过则保持默认颜色，不再使用黄/橙/红三级颜色。
        /// </summary>
        private void StyleHistoryRowByThreshold(DataGridViewRow row)
        {
            if (row == null || row.IsNewRow) return;

            Color alarmBack = Color.FromArgb(104, 35, 38);
            Color alarmFore = Color.FromArgb(255, 126, 126);
            Color alarmSelectionBack = Color.FromArgb(126, 40, 44);

            for (int colIndex = 0; colIndex < _historyGrid.Columns.Count; colIndex++)
            {
                var column = _historyGrid.Columns[colIndex];
                var cell = row.Cells[colIndex];

                cell.Style.BackColor = _historyGrid.DefaultCellStyle.BackColor;
                cell.Style.ForeColor = _historyGrid.DefaultCellStyle.ForeColor;
                cell.Style.SelectionBackColor = _historyGrid.DefaultCellStyle.SelectionBackColor;
                cell.Style.SelectionForeColor = _historyGrid.DefaultCellStyle.SelectionForeColor;

                string metric = column.HeaderText;
                GradeThreshold threshold = _gradeSettings.FirstOrDefault(
                    x => string.Equals(x.Metric, metric, StringComparison.OrdinalIgnoreCase));

                if (threshold == null)
                    continue;

                double parsed;
                if (!double.TryParse(Convert.ToString(cell.Value), out parsed))
                    continue;

                if (Math.Abs(parsed) > threshold.Grade1)
                {
                    cell.Style.BackColor = alarmBack;
                    cell.Style.ForeColor = alarmFore;
                    cell.Style.SelectionBackColor = alarmSelectionBack;
                    cell.Style.SelectionForeColor = Color.White;
                }
            }

            // 等级列也避免多色：只有“不合格”使用红色，其余等级保持默认文字色。
            if (_historyGrid.Columns.Count > 0)
            {
                int gradeIndex = _historyGrid.Columns.Count - 1;
                var gradeCell = row.Cells[gradeIndex];
                string grade = Convert.ToString(gradeCell.Value);
                if (grade == "不合格")
                {
                    gradeCell.Style.BackColor = alarmBack;
                    gradeCell.Style.ForeColor = alarmFore;
                    gradeCell.Style.SelectionBackColor = alarmSelectionBack;
                    gradeCell.Style.SelectionForeColor = Color.White;
                }
            }
        }

        /// <summary>
        /// 当等级阈值修改后，重新检查并刷新全部历史记录颜色。
        /// </summary>
        private void RefreshHistoryThresholdColors()
        {
            foreach (DataGridViewRow row in _historyGrid.Rows)
                StyleHistoryRowByThreshold(row);

            _historyGrid.Invalidate();
        }

        /// <summary>
        /// 按每个指标的三级阈值计算当前砖最终等级，遵循“最差指标决定等级”。
        /// </summary>
        private string EvaluateGrade(FlatnessResult r)
        {
            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase)
            {
                ["SVE"] = Math.Abs(r.SVE),
                ["BAR"] = Math.Abs(r.BAR),
                ["AN+"] = Math.Abs(r.ANPlus),
                ["AN-"] = Math.Abs(r.ANMinus),
                ["LX+"] = Math.Abs(r.LXPlus),
                ["LX-"] = Math.Abs(r.LXMinus),
                ["LY+"] = Math.Abs(r.LYPlus),
                ["LY-"] = Math.Abs(r.LYMinus),
                ["CE+"] = Math.Abs(r.CEPlus),
                ["CE-"] = Math.Abs(r.CEMinus)
            };

            int worst = 1;
            foreach (var t in _gradeSettings)
            {
                double v;
                if (!values.TryGetValue(t.Metric, out v)) continue;

                int g = v <= t.Grade1 ? 1 :
                        v <= t.Grade2 ? 2 :
                        v <= t.Grade3 ? 3 : 4;
                worst = Math.Max(worst, g);
            }

            if (worst == 1) return "一级品";
            if (worst == 2) return "二级品";
            if (worst == 3) return "三级品";
            return "不合格";
        }

        /// <summary>
        /// 校验并保存等级阈值/瓷砖规格，同时同步历史告警和当前结果告警。
        /// </summary>
        private void ReadGradeSettings()
        {
            double length;
            double width;

            if (!double.TryParse(_tileLengthTextBox.Text, out length) || length <= 0 ||
                !double.TryParse(_tileWidthTextBox.Text, out width) || width <= 0)
            {
                MessageBox.Show(
                    "瓷砖长度和宽度必须输入大于0的数字。",
                    "参数错误",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            var pending = new List<GradeThreshold>();

            for (int i = 0; i < _gradeSettings.Count && i < _gradeGrid.Rows.Count; i++)
            {
                double g1, g2, g3;

                if (!TryReadCellDouble(_gradeGrid, i, 1, out g1) ||
                    !TryReadCellDouble(_gradeGrid, i, 2, out g2) ||
                    !TryReadCellDouble(_gradeGrid, i, 3, out g3))
                {
                    MessageBox.Show("等级阈值必须输入数字。", "参数错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (g1 < 0 || g2 < 0 || g3 < 0 || g1 > g2 || g2 > g3)
                {
                    MessageBox.Show(
                        _gradeSettings[i].Metric + " 的等级阈值必须满足：一级 ≤ 二级 ≤ 三级，且不能为负数。",
                        "参数错误",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning);
                    return;
                }

                pending.Add(new GradeThreshold
                {
                    Metric = _gradeSettings[i].Metric,
                    Grade1 = g1,
                    Grade2 = g2,
                    Grade3 = g3
                });
            }

            for (int i = 0; i < pending.Count; i++)
            {
                _gradeSettings[i].Grade1 = pending[i].Grade1;
                _gradeSettings[i].Grade2 = pending[i].Grade2;
                _gradeSettings[i].Grade3 = pending[i].Grade3;
            }

            _tileLength = length;
            _tileWidth = width;
            _tileDiagonal = Math.Sqrt(length * length + width * width);
            _surface3D.SetTileSize(_tileLength, _tileWidth);

            _tileLengthTextBox.Text = _tileLength.ToString("0.00");
            _tileWidthTextBox.Text = _tileWidth.ToString("0.00");
            _tileDiagonalValueLabel.Text = _tileDiagonal.ToString("0.00") + " mm";
            _tileDiagonalValueLabel.ForeColor = Color.WhiteSmoke;

            // 等级阈值发生变化后：
            // 1) 历史记录立即按新阈值重新着色；
            // 2) 左下角当前平整度结果也立即按新阈值重新判断红色告警。
            RefreshHistoryThresholdColors();
            _resultControl.SetThresholds(_gradeSettings);

            MessageBox.Show(
                "设置已保存。\n" +
                "长度：" + _tileLength.ToString("0.00") + " mm\n" +
                "宽度：" + _tileWidth.ToString("0.00") + " mm\n" +
                "对角线：" + _tileDiagonal.ToString("0.00") + " mm",
                "提示",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        /// <summary>
        /// 从比例补偿表读取用户输入并写回运行参数。
        /// </summary>
        private void ReadCompensationSettings()
        {
            var ratios = new double[_compSettings.Count];
            var offsets = new double[_compSettings.Count];

            for (int i = 0; i < _compSettings.Count && i < _compGrid.Rows.Count; i++)
            {
                if (!TryReadCellDouble(_compGrid, i, 1, out ratios[i]) ||
                    !TryReadCellDouble(_compGrid, i, 2, out offsets[i]))
                {
                    MessageBox.Show("比例与补偿必须输入数字。", "参数错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            for (int i = 0; i < _compSettings.Count; i++)
            {
                _compSettings[i].Ratio = ratios[i];
                _compSettings[i].Offset = offsets[i];
            }

            MessageBox.Show("比例与补偿设置已保存。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// 切换物理传感器数量并同步选择控件和校准数据。
        /// </summary>
        private void SetSensorCount(int count)
        {
            if (count != 5 && count != 7 && count != 9 && count != 11)
                count = 7;

            _currentSensorCount = count;
            _sensorSelection.SensorCount = count;

            // 传感器数量变化后重建对应数量的校准行，禁止出现 7 个传感器却显示 S8。
            _calibrationItems = MockData.CreateCalibration(count);

            RefreshCalibrationGrid();
        }

        /// <summary>
        /// 把当前传感器实时值和校准参数刷新到校准表。
        /// </summary>
        private void RefreshCalibrationGrid()
        {
            // 用户正在编辑板补偿时，不刷新表格，避免输入被定时器覆盖。
            if (_calibrationGrid.IsCurrentCellInEditMode)
                return;

            if (_calibrationItems == null || _calibrationItems.Count != _currentSensorCount)
                _calibrationItems = MockData.CreateCalibration(_currentSensorCount);

            _calibrationGrid.Rows.Clear();

            foreach (var x in _calibrationItems.Take(_currentSensorCount))
            {
                _calibrationGrid.Rows.Add(
                    "S" + x.SensorIndex,
                    x.RawValue.ToString("+0.00;-0.00;0.00"),
                    x.ZeroOffset.ToString("+0.00;-0.00;0.00"),
                    x.BoardCompensation.ToString("0.00"));
            }

            StyleReadOnlyColumns(_calibrationGrid, 0, 1, 2);
            StyleEditableColumns(_calibrationGrid, 3);
        }

        /// <summary>
        /// 执行一键置零：把当前原始值反向写入 ZeroOffset。
        /// </summary>
        private void CalibrateZero()
        {
            foreach (var x in _calibrationItems)
                x.ZeroOffset = -x.RawValue;

            RefreshCalibrationGrid();
        }

        /// <summary>
        /// 从指定校准表行读取板补偿值并写回模型。
        /// </summary>
        private void UpdateBoardCompensationFromRow(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= _calibrationItems.Count)
                return;

            double value;
            if (!TryReadCellDouble(_calibrationGrid, rowIndex, 3, out value))
                return;

            _calibrationItems[rowIndex].BoardCompensation = value;
        }

        /// <summary>
        /// 读取整张传感器校准表中的板补偿输入。
        /// </summary>
        private void ReadBoardCompensation()
        {
            for (int i = 0; i < _calibrationItems.Count && i < _calibrationGrid.Rows.Count; i++)
            {
                double value;
                if (!TryReadCellDouble(_calibrationGrid, i, 3, out value))
                {
                    MessageBox.Show("板补偿必须输入数字。", "参数错误", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                _calibrationItems[i].BoardCompensation = value;
            }

            MessageBox.Show("板补偿已保存。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// 安全读取表格单元格中的 double；输入无效时返回 false。
        /// </summary>
        private static bool TryReadCellDouble(DataGridView grid, int row, int col, out double value)
        {
            value = 0.0;
            if (row < 0 || row >= grid.Rows.Count || col < 0 || col >= grid.Columns.Count)
                return false;

            object raw = grid.Rows[row].Cells[col].Value;
            return raw != null && double.TryParse(Convert.ToString(raw), out value);
        }

        /// <summary>
        /// 把对象转换为 double，转换失败时返回备用值。
        /// </summary>
        private static double ToDouble(object value, double fallback)
        {
            if (value == null) return fallback;
            double d;
            return double.TryParse(Convert.ToString(value), out d) ? d : fallback;
        }
    }


    /// <summary>
    /// 去掉 Windows 默认虚线焦点框的 TabControl。
    /// 鼠标切换页签功能保持不变，只让工业界面的选中状态更干净。
    /// </summary>
    internal sealed class CleanTabControl : TabControl
    {
        protected override bool ShowFocusCues
        {
            get { return false; }
        }
    }
}
