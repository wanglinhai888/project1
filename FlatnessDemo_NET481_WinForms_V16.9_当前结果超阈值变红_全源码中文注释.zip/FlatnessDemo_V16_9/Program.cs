// ============================================================================
// 文件：Program.cs
// 作用：WinForms 程序入口，仅负责初始化 Windows 界面环境并启动 MainForm。
// 说明：业务逻辑、算法和绘制代码不应放在本文件中。
// ============================================================================
using System;
using System.Windows.Forms;

namespace FlatnessDemo
{
    /// <summary>
    /// 应用程序入口类。
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// Windows 桌面程序主入口。
        /// STAThread 是 WinForms/OLE/剪贴板等组件正常工作的线程模型要求。
        /// </summary>
        [STAThread]
        private static void Main()
        {
            // 启用操作系统视觉样式，让标准控件使用当前 Windows 主题。
            Application.EnableVisualStyles();

            // 使用 GDI+ 兼容的文本渲染方式，保持现有 Demo 的字体显示行为。
            Application.SetCompatibleTextRenderingDefault(false);

            // 创建并运行主窗体；关闭主窗体后应用程序退出。
            Application.Run(new MainForm());
        }
    }
}
