// ============================================================================
// 文件：Theme.cs
// 作用：集中定义界面颜色、字体以及常用控件的统一创建方法。
// 目的：避免 MainForm 和各自定义控件到处硬编码颜色/字体，方便统一换肤。
// ============================================================================
using System.Drawing;
using System.Windows.Forms;

namespace FlatnessDemo
{
    /// <summary>
    /// 平整度 Demo 的全局视觉主题。
    /// </summary>
    internal static class Theme
    {
        // ------------------------------
        // 全局颜色
        // ------------------------------
        public static readonly Color Header = Color.FromArgb(20, 63, 105);      // 顶部标题栏
        public static readonly Color Nav = Color.FromArgb(15, 53, 84);          // 导航/Tab 深蓝背景
        public static readonly Color Panel = Color.FromArgb(20, 62, 95);        // 主面板背景
        public static readonly Color Panel2 = Color.FromArgb(29, 78, 116);      // 次级面板背景
        public static readonly Color Border = Color.FromArgb(51, 101, 138);     // 边框/网格线
        public static readonly Color Accent = Color.FromArgb(20, 141, 205);     // 当前选中项高亮蓝
        public static readonly Color Text = Color.WhiteSmoke;                    // 主文字
        public static readonly Color Muted = Color.FromArgb(178, 205, 225);     // 次要文字
        public static readonly Color Good = Color.FromArgb(61, 195, 62);        // 正常/一级品
        public static readonly Color Warning = Color.FromArgb(241, 188, 53);    // 警示/二级品
        public static readonly Color Bad = Color.FromArgb(235, 75, 75);         // 超阈值/不合格
        public static readonly Color Grid = Color.FromArgb(42, 87, 121);        // 普通网格

        /// <summary>
        /// 创建项目统一字体。所有 UI 尽量从这里创建，避免字体风格不一致。
        /// </summary>
        public static Font Font(float size, FontStyle style = FontStyle.Regular)
        {
            return new Font("Microsoft YaHei UI", size, style);
        }

        /// <summary>
        /// 创建透明背景的标准 Label。
        /// </summary>
        public static Label Label(string text, float size = 10f, FontStyle style = FontStyle.Regular)
        {
            return new Label
            {
                Text = text,
                ForeColor = Text,
                Font = Font(size, style),
                AutoSize = true,
                BackColor = Color.Transparent
            };
        }

        /// <summary>
        /// 创建项目统一风格按钮。
        /// </summary>
        public static Button Button(string text)
        {
            return new Button
            {
                Text = text,
                FlatStyle = FlatStyle.Flat,
                BackColor = Panel2,
                ForeColor = Text,
                Font = Font(9f, FontStyle.Bold),
                Height = 32
            };
        }

        /// <summary>
        /// 创建统一样式的 DataGridView。
        /// 各页面只需要再定义列、可编辑列和滚动行为即可。
        /// </summary>
        public static DataGridView CreateGrid()
        {
            var g = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Panel,
                BorderStyle = BorderStyle.None,
                GridColor = Border,
                EnableHeadersVisualStyles = false,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AllowUserToResizeRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                SelectionMode = DataGridViewSelectionMode.CellSelect
            };

            // 统一数据行高度。
            g.RowTemplate.Height = 23;

            // 表头样式。
            g.ColumnHeadersDefaultCellStyle.BackColor = Header;
            g.ColumnHeadersDefaultCellStyle.ForeColor = Text;
            g.ColumnHeadersDefaultCellStyle.Font = Font(9f, FontStyle.Bold);

            // 数据区样式。
            g.DefaultCellStyle.BackColor = Panel2;
            g.DefaultCellStyle.ForeColor = Text;
            g.DefaultCellStyle.SelectionBackColor = Accent;
            g.DefaultCellStyle.SelectionForeColor = Color.White;
            g.DefaultCellStyle.Font = Font(9f);
            g.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            return g;
        }
    }
}
