// ============================================================================
// 文件：MockData.cs
// 作用：为 Demo 生成模拟测点、3D 高度场和传感器校准数据。
// 注意：正式接入硬件后，应由采集层替换这些随机数据，本文件不参与真实生产计算。
// ============================================================================
using System;
using System.Collections.Generic;
using FlatnessDemo.Models;

namespace FlatnessDemo
{
    /// <summary>
    /// Demo 专用模拟数据工厂。
    /// </summary>
    internal static class MockData
    {
        // 复用同一个随机数实例，避免频繁 new Random 导致短时间内序列重复。
        private static readonly Random Rng = new Random();

        /// <summary>
        /// 生成一片砖的 5×5 关键测点数据。
        /// 仅给实际有名称的点赋值，空白位置由 3D 表面生成方法补齐。
        /// </summary>
        public static FlatnessInput CreateInput()
        {
            var p = new FlatnessInput();
            string[] names =
            {
                "A","A1","DA","D1","D",
                "A2","A3","D3","D2",
                "AB","CE","CD",
                "B2","B3","C3","C2",
                "B","B1","BC","C1","C"
            };

            // 模拟 0.10~0.82 mm 范围的测量值。
            foreach (var n in names)
                p[n] = 0.10 + Rng.NextDouble() * 0.72;

            return p;
        }

        /// <summary>
        /// 把算法测点转换成 5×5 高度场，供 Flatness3DControl 演示绘制。
        /// 空位使用相邻点均值填充，正式项目可替换为真实 11×N 或插值后的高度矩阵。
        /// </summary>
        public static double[,] CreateSurface(FlatnessInput p)
        {
            return new[,]
            {
                {p["A"],  p["A1"], p["DA"], p["D1"], p["D"]},
                {p["A2"], p["A3"], (p["A3"]+p["D3"])/2, p["D3"], p["D2"]},
                {p["AB"], (p["AB"]+p["CE"])/2, p["CE"], (p["CE"]+p["CD"])/2, p["CD"]},
                {p["B2"], p["B3"], (p["B3"]+p["C3"])/2, p["C3"], p["C2"]},
                {p["B"],  p["B1"], p["BC"], p["C1"], p["C"]}
            };
        }

        /// <summary>
        /// 按传感器数量生成校准页演示数据。
        /// </summary>
        public static List<SensorCalibrationItem> CreateCalibration(int count)
        {
            var list = new List<SensorCalibrationItem>();
            for (int i = 1; i <= count; i++)
            {
                // 模拟零点附近 ±0.15 mm 的实时原始值。
                var raw = Math.Round((Rng.NextDouble() - 0.5) * 0.30, 3);
                list.Add(new SensorCalibrationItem
                {
                    SensorIndex = i,
                    RawValue = raw,
                    ZeroOffset = 0.0,
                    BoardCompensation = 0.0
                });
            }
            return list;
        }
    }
}
