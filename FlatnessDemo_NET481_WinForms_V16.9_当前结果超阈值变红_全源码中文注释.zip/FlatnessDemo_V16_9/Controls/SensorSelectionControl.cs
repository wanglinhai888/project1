﻿// ============================================================================
// 文件：SensorSelectionControl.cs
// 作用：绘制“调整顺序/传感器选择”页面中的物理传感器与算法取点映射。
// 规则：物理传感器可为 5/7/9/11 个，算法最终选 5 个；两端和中心强制保留，
//       其余位置可选；算法点位始终保留原始物理编号，不压缩重编号。
// ============================================================================
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace FlatnessDemo.Controls
{
    /// <summary>
    /// 物理传感器选择与 5×5 算法点位映射控件。
    /// </summary>
    public sealed class SensorSelectionControl : Control
    {
        // 5×5 Planar 算法点位名称。空字符串代表该格没有命名测点。
        private static readonly string[,] AlgorithmNames =
        {
            {"A","A1","DA","D1","D"},
            {"A2","A3","","D3","D2"},
            {"AB","","CE","","CD"},
            {"B2","B3","","C3","C2"},
            {"B","B1","BC","C1","C"}
        };

        // 物理传感器圆点所在的基准 Y 坐标。
        private const int SensorY = 72;
        private int _sensorCount = 7;
        private List<int> _selected = new List<int> { 1, 3, 4, 6, 7 };

        /// <summary>当算法选择的原始物理传感器编号发生变化时触发。</summary>
        public event EventHandler SelectionChanged;

        /// <summary>
        /// 当前物理传感器数量，只允许 5/7/9/11。设置后会自动恢复默认 5 点选择。
        /// </summary>
        public int SensorCount
        {
            get { return _sensorCount; }
            set
            {
                _sensorCount = NormalizeCount(value);
                ResetDefaultSelection();
            }
        }

        /// <summary>当前算法选择的 5 个原始物理传感器编号。</summary>
        public IReadOnlyList<int> SelectedIndices
        {
            get { return _selected; }
        }

        /// <summary>初始化选择控件的双缓冲和基础尺寸。</summary>
        public SensorSelectionControl()
        {
            DoubleBuffered = true;
            BackColor = Theme.Panel;
            MinimumSize = new Size(440, 410);
        }

        /// <summary>
        /// 根据当前传感器总数生成默认 5 点：两端、中心、1/4、3/4 位置。
        /// </summary>
        public void ResetDefaultSelection()
        {
            int center = (_sensorCount + 1) / 2;
            int q1 = 1 + (_sensorCount - 1) / 4;
            int q3 = 1 + 3 * (_sensorCount - 1) / 4;

            _selected = new List<int> { 1, q1, center, q3, _sensorCount }
                .Distinct()
                .OrderBy(x => x)
                .ToList();

            while (_selected.Count < 5)
            {
                for (int i = 2; i < _sensorCount && _selected.Count < 5; i++)
                    if (!_selected.Contains(i))
                        _selected.Add(i);

                _selected.Sort();
            }

            Invalidate();
            SelectionChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// 处理物理传感器圆点点击：两端/中心不可取消，其余位置最多选到 5 个。
        /// </summary>
        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);

            int left = 74;
            int right = Width - 28;
            float step = (right - left) / (float)Math.Max(1, _sensorCount - 1);

            if (e.Y < SensorY - 20 || e.Y > SensorY + 28)
                return;

            int index = (int)Math.Round((e.X - left) / step) + 1;
            if (index < 1 || index > _sensorCount)
                return;

            int center = (_sensorCount + 1) / 2;

            // 两端和中心固定必须保留。
            if (index == 1 || index == center || index == _sensorCount)
                return;

            if (_selected.Contains(index))
            {
                if (_selected.Count > 3)
                    _selected.Remove(index);
            }
            else
            {
                if (_selected.Count >= 5)
                    return;

                _selected.Add(index);
                _selected.Sort();
            }

            Invalidate();
            SelectionChanged?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// 绘制当前选择、物理传感器圆点、算法原始编号、5×5 点位表和输送方向箭头。
        /// </summary>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            using (var titleFont = Theme.Font(9.5f, FontStyle.Bold))
            using (var normalFont = Theme.Font(8.2f))
            using (var strongFont = Theme.Font(9f, FontStyle.Bold))
            using (var pointFont = Theme.Font(9.2f, FontStyle.Bold))
            using (var gridPen = new Pen(Theme.Border, 1f))
            using (var arrowPen = new Pen(Theme.Warning, 6f))
            using (var selectedBrush = new SolidBrush(Color.DeepSkyBlue))
            using (var unselectedBrush = new SolidBrush(Color.FromArgb(95, 95, 95)))
            using (var algorithmBrush = new SolidBrush(Color.DeepSkyBlue))
            using (var secondaryBrush = new SolidBrush(Color.FromArgb(190, 210, 225)))
            {
                // 1. 当前选择
                g.DrawString(
                    "当前选择：" + string.Join("、", _selected),
                    titleFont,
                    Brushes.WhiteSmoke,
                    12,
                    8);

                // 2. 物理传感器
                g.DrawString(
                    "物理传感器（点击可选位置）",
                    normalFont,
                    secondaryBrush,
                    12,
                    32);

                int left = 74;
                int right = Width - 28;
                float step = (right - left) / (float)Math.Max(1, _sensorCount - 1);
                int center = (_sensorCount + 1) / 2;

                for (int i = 1; i <= _sensorCount; i++)
                {
                    float x = left + (i - 1) * step;
                    bool selected = _selected.Contains(i);
                    bool fixedPos = i == 1 || i == center || i == _sensorCount;

                    g.FillEllipse(selected ? selectedBrush : unselectedBrush, x - 6, SensorY - 6, 12, 12);

                    string text = i.ToString() + (fixedPos ? "*" : "");
                    SizeF size = g.MeasureString(text, strongFont);
                    g.DrawString(text, strongFont, Brushes.WhiteSmoke, x - size.Width / 2, SensorY + 11);
                }

                if (_selected.Count != 5)
                {
                    g.DrawString(
                        "请选择5个位置（两端和中心固定）",
                        strongFont,
                        Brushes.Goldenrod,
                        12,
                        112);
                    return;
                }

                // 3. 算法取点：与物理传感器区留出独立间距，绝不叠字。
                int algorithmTitleY = 116;
                int algorithmIndexY = 137;
                int gridTop = 160;
                int gridLeft = 104;
                int gridRight = Width - 22;
                int gridBottom = Height - 14;

                int cellW = Math.Max(1, (gridRight - gridLeft) / 5);
                int cellH = Math.Max(1, (gridBottom - gridTop) / 5);

                g.DrawString("算法取点", normalFont, secondaryBrush, gridLeft, algorithmTitleY);

                for (int c = 0; c < 5; c++)
                {
                    string idx = _selected[c].ToString();
                    SizeF sz = g.MeasureString(idx, strongFont);
                    g.DrawString(
                        idx,
                        strongFont,
                        algorithmBrush,
                        gridLeft + c * cellW + (cellW - sz.Width) / 2,
                        algorithmIndexY);
                }

                // 左侧纵向显示真实原始传感器编号，不压缩成 1~5。
                for (int r = 0; r < 5; r++)
                {
                    string idx = _selected[r].ToString();
                    SizeF sz = g.MeasureString(idx, strongFont);
                    g.DrawString(
                        idx,
                        strongFont,
                        algorithmBrush,
                        gridLeft - 30,
                        gridTop + r * cellH + (cellH - sz.Height) / 2);
                }

                // 输送方向箭头
                float arrowX = 44f;
                float arrowTop = gridTop + 6;
                float arrowBottom = gridBottom - 6;
                g.DrawLine(arrowPen, arrowX, arrowBottom, arrowX, arrowTop + 12);

                using (var arrowBrush = new SolidBrush(Theme.Warning))
                {
                    g.FillPolygon(
                        arrowBrush,
                        new[]
                        {
                            new PointF(arrowX - 10, arrowTop + 20),
                            new PointF(arrowX, arrowTop),
                            new PointF(arrowX + 10, arrowTop + 20)
                        });
                }

                // 5×5 算法网格
                for (int r = 0; r <= 5; r++)
                    g.DrawLine(gridPen, gridLeft, gridTop + r * cellH, gridLeft + 5 * cellW, gridTop + r * cellH);

                for (int c = 0; c <= 5; c++)
                    g.DrawLine(gridPen, gridLeft + c * cellW, gridTop, gridLeft + c * cellW, gridTop + 5 * cellH);

                for (int r = 0; r < 5; r++)
                {
                    for (int c = 0; c < 5; c++)
                    {
                        string name = AlgorithmNames[r, c];
                        if (string.IsNullOrEmpty(name))
                            continue;

                        SizeF sz = g.MeasureString(name, pointFont);
                        g.DrawString(
                            name,
                            pointFont,
                            Brushes.WhiteSmoke,
                            gridLeft + c * cellW + (cellW - sz.Width) / 2,
                            gridTop + r * cellH + (cellH - sz.Height) / 2);
                    }
                }
            }
        }

        /// <summary>把非法传感器数量回退到默认 7 个。</summary>
        private static int NormalizeCount(int value)
        {
            if (value == 5 || value == 7 || value == 9 || value == 11)
                return value;

            return 7;
        }
    }
}
