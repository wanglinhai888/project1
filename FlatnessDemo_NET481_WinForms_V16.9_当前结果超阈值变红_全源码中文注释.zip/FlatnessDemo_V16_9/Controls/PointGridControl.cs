﻿// ============================================================================
// 文件：PointGridControl.cs
// 作用：绘制当前砖 5×5 命名测点表、输送方向箭头以及 X/Y 方向标识。
// 风格：测点表使用浅灰底、深色数值和较深的测点名，接近参考设备界面。
// ============================================================================
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using FlatnessDemo.Models;

namespace FlatnessDemo.Controls
{
    /// <summary>当前砖 5×5 平整度测点显示控件。</summary>
    public sealed class PointGridControl : Control
    {
        // 5×5 网格中的业务点位名称。空字符串表示该位置无命名测点。
        private static readonly string[,] Names =
        {
            {"A","A1","DA","D1","D"},
            {"A2","A3","","D3","D2"},
            {"AB","","CE","","CD"},
            {"B2","B3","","C3","C2"},
            {"B","B1","BC","C1","C"}
        };

        private FlatnessInput _input = new FlatnessInput();

        /// <summary>初始化双缓冲、颜色和最小尺寸。</summary>
        public PointGridControl()
        {
            DoubleBuffered = true;
            BackColor = Theme.Panel;
            ForeColor = Theme.Text;
            MinimumSize = new Size(420, 300);
        }

        /// <summary>设置当前砖测点并触发重绘。</summary>
        public void SetInput(FlatnessInput input)
        {
            _input = input ?? new FlatnessInput();
            Invalidate();
        }

        /// <summary>绘制标题、白色 5×5 网格、传送带箭头和 X/Y 轴。</summary>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            using (var titleFont = Theme.Font(12f, FontStyle.Bold))
            using (var nameFont = Theme.Font(11f, FontStyle.Regular))
            using (var valueFont = Theme.Font(12.5f, FontStyle.Regular))
            using (var axisFont = Theme.Font(12f, FontStyle.Bold))
            using (var gridPen = new Pen(Color.FromArgb(58, 58, 58), 1f))
            using (var axisPen = new Pen(Color.White, 3f))
            using (var arrowPen = new Pen(Color.FromArgb(250, 233, 73), 5f))
            using (var axisLabelBrush = new SolidBrush(Color.White))
            using (var arrowBrush = new SolidBrush(Color.FromArgb(250, 233, 73)))
            using (var cellBrush = new SolidBrush(Color.FromArgb(240, 240, 240)))
            {
                axisPen.StartCap = LineCap.Square;
                axisPen.EndCap = LineCap.Square;

                g.DrawString("当前砖平整度测点", titleFont, Brushes.WhiteSmoke, 14, 12);

                // V16.5：给 X/Y 轴留出明确的安全边距，避免轴线贴边后与容器边框混在一起。
                int left = 58;
                int top = 52;
                int right = Width - 42;
                int bottom = Height - 42;
                int w = Math.Max(1, (right - left) / 5);
                int h = Math.Max(1, (bottom - top) / 5);
                int gridRight = left + 5 * w;
                int gridBottom = top + 5 * h;

                for (int r = 0; r < 5; r++)
                {
                    for (int c = 0; c < 5; c++)
                    {
                        var rect = new Rectangle(left + c * w, top + r * h, w, h);
                        g.FillRectangle(cellBrush, rect);
                    }
                }

                for (int r = 0; r <= 5; r++)
                    g.DrawLine(gridPen, left, top + r * h, gridRight, top + r * h);
                for (int c = 0; c <= 5; c++)
                    g.DrawLine(gridPen, left + c * w, top, left + c * w, gridBottom);

                // 传送带方向箭头（黄色）
                int conveyorX = left - 26;
                g.DrawLine(arrowPen, conveyorX, gridBottom - 4, conveyorX, top + 22);
                g.FillPolygon(arrowBrush, new[]
                {
                    new Point(conveyorX - 10, top + 28),
                    new Point(conveyorX, top + 6),
                    new Point(conveyorX + 10, top + 28)
                });

                // X / Y 坐标轴（白色、3px、与网格外框分离）
                int xAxisY = gridBottom + 13;
                int yAxisX = gridRight + 13;
                g.DrawLine(axisPen, left - 2, xAxisY, yAxisX, xAxisY);
                g.DrawLine(axisPen, yAxisX, xAxisY, yAxisX, top - 2);

                // 标签贴近轴线，不再贴容器边缘。
                g.DrawString("X", axisFont, axisLabelBrush, left - 2, xAxisY + 3);
                g.DrawString("Y", axisFont, axisLabelBrush, yAxisX + 4, top - 7);

                for (int r = 0; r < 5; r++)
                {
                    for (int c = 0; c < 5; c++)
                    {
                        var name = Names[r, c];
                        if (string.IsNullOrEmpty(name))
                            continue;

                        var rect = new Rectangle(left + c * w, top + r * h, w, h);
                        DrawCell(g, rect, name, _input[name], nameFont, valueFont);
                    }
                }
            }
        }

        /// <summary>在单个格子中绘制测点名称和数值。</summary>
        private static void DrawCell(Graphics g, Rectangle rect, string name, double value, Font nameFont, Font valueFont)
        {
            using (var nameColor = new SolidBrush(Color.FromArgb(105, 105, 105)))
            using (var valueColor = new SolidBrush(Color.FromArgb(28, 28, 28)))
            using (var sf = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center })
            {
                var topRect = new RectangleF(rect.X, rect.Y + 5, rect.Width, rect.Height * 0.38f);
                var bottomRect = new RectangleF(rect.X, rect.Y + rect.Height * 0.36f, rect.Width, rect.Height * 0.56f);

                g.DrawString(name, nameFont, nameColor, topRect, sf);
                g.DrawString(value.ToString("0.00"), valueFont, valueColor, bottomRect, sf);
            }
        }
    }
}
