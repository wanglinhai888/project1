﻿// ============================================================================
// 文件：FlatnessResultControl.cs
// 作用：绘制左下角 Planar 平整度结果表（正数/负数），并加载指标图标。
// 告警：结果绝对值超过该指标一级阈值时，数值文字统一变成红色；不使用黄/橙多级色。
// ============================================================================
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Windows.Forms;
using FlatnessDemo.Models;

namespace FlatnessDemo.Controls
{
    /// <summary>
    /// Planar 平整度结果显示控件。正负表等宽、等高、等行高；
    /// 指标名称由 PNG 图标直接提供，数值超过一级阈值时统一使用红色粗体。
    /// </summary>
    public sealed class FlatnessResultControl : Control
    {
        private readonly Dictionary<string, Image> _iconCache = new Dictionary<string, Image>(StringComparer.OrdinalIgnoreCase);

        // 当前“一级品”阈值。结果值的绝对值只要超过对应一级阈值，就使用红色显示。
        // 使用指标名称作为键，保证 AN+/AN-/LX+/... 能逐项匹配等级设置页。
        private readonly Dictionary<string, double> _grade1Thresholds =
            new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);

        private FlatnessResult _result = new FlatnessResult();

        /// <summary>初始化结果控件和最小尺寸。</summary>
        public FlatnessResultControl()
        {
            DoubleBuffered = true;
            BackColor = Theme.Panel2;
            ForeColor = Theme.Text;
            MinimumSize = new Size(420, 200);
        }

        /// <summary>设置当前砖平整度结果并触发重绘。</summary>
        public void SetResult(FlatnessResult result)
        {
            _result = result ?? new FlatnessResult();
            Invalidate();
        }

        /// <summary>
        /// 同步等级设置页中的阈值。
        /// 这里只使用 Grade1（一级品上限）作为“是否告警变红”的判断标准；
        /// Grade2/Grade3 仍由主窗体用于最终等级判定。
        /// </summary>
        public void SetThresholds(IEnumerable<GradeThreshold> thresholds)
        {
            _grade1Thresholds.Clear();

            if (thresholds != null)
            {
                foreach (var item in thresholds)
                {
                    if (item == null || string.IsNullOrWhiteSpace(item.Metric))
                        continue;

                    _grade1Thresholds[item.Metric] = Math.Max(0.0, item.Grade1);
                }
            }

            Invalidate();
        }

        /// <summary>释放缓存的 PNG 图标资源。</summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                foreach (var pair in _iconCache)
                {
                    if (pair.Value != null)
                        pair.Value.Dispose();
                }
                _iconCache.Clear();
            }
            base.Dispose(disposing);
        }

        /// <summary>绘制标题、正数表、负数表和阈值告警数值。</summary>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            var g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            using (var titleFont = Theme.Font(11.2f, FontStyle.Bold))
            using (var headerFont = Theme.Font(10.8f, FontStyle.Bold))
            using (var rowValueFont = Theme.Font(12.5f, FontStyle.Regular))
            using (var alarmValueFont = Theme.Font(12.5f, FontStyle.Bold))
            using (var gridPen = new Pen(Color.FromArgb(70, 70, 70), 1f))
            using (var yellowBrush = new SolidBrush(Color.FromArgb(236, 238, 73)))
            using (var whiteBrush = new SolidBrush(Color.White))
            using (var valueBrush = new SolidBrush(Color.FromArgb(24, 24, 24)))
            using (var alarmValueBrush = new SolidBrush(Color.FromArgb(210, 35, 35)))
            using (var headerTextBrush = new SolidBrush(Color.FromArgb(38, 38, 38)))
            {
                g.DrawString("Planar 平整度结果", titleFont, Brushes.WhiteSmoke, 14, 9);

                int left = 12;
                int top = 36;
                int right = Width - 12;
                int bottom = Height - 10;
                int gap = 16;

                // V16.6：两个表外框严格等宽、等高、同一基线。
                int availableW = Math.Max(1, right - left - gap);
                int tableW = Math.Max(1, availableW / 2);
                int tableH = Math.Max(1, bottom - top);

                var positiveRect = new Rectangle(left, top, tableW, tableH);
                var negativeRect = new Rectangle(left + tableW + gap, top, tableW, tableH);

                string[] positiveMetrics = { "AN+", "LX+", "LY+", "CE+", "SVE", "BAR", "RUL" };
                double?[] positiveValues =
                {
                    _result.ANPlus,
                    _result.LXPlus,
                    _result.LYPlus,
                    _result.CEPlus,
                    _result.SVE,
                    _result.BAR,
                    null // RUL 当前 Demo 尚未正式计算，因此不参与阈值告警。
                };

                string[] negativeMetrics = { "AN-", "LX-", "LY-", "CE-" };
                double?[] negativeValues =
                {
                    _result.ANMinus,
                    _result.LXMinus,
                    _result.LYMinus,
                    _result.CEMinus
                };

                DrawMetricTable(g, positiveRect, "正数", positiveMetrics, positiveValues,
                    headerFont, rowValueFont, alarmValueFont, gridPen, yellowBrush, whiteBrush,
                    valueBrush, alarmValueBrush, headerTextBrush);
                DrawMetricTable(g, negativeRect, "负数", negativeMetrics, negativeValues,
                    headerFont, rowValueFont, alarmValueFont, gridPen, yellowBrush, whiteBrush,
                    valueBrush, alarmValueBrush, headerTextBrush);
            }
        }

        /// <summary>绘制一个结果表：黄色表头、图标列、数值列以及统一的 7 行高度。</summary>
        private void DrawMetricTable(Graphics g, Rectangle rect, string headerText,
            string[] metrics, double?[] values, Font headerFont, Font valueFont, Font alarmValueFont,
            Pen borderPen, Brush headerBrush, Brush fillBrush, Brush valueBrush,
            Brush alarmValueBrush, Brush headerTextBrush)
        {
            if (rect.Width <= 40 || rect.Height <= 40)
                return;

            int headerH = Math.Max(24, Math.Min(31, rect.Height / 8));
            g.FillRectangle(fillBrush, rect);
            g.FillRectangle(headerBrush, rect.X, rect.Y, rect.Width, headerH);
            g.DrawRectangle(borderPen, rect.X, rect.Y, rect.Width - 1, rect.Height - 1);

            using (var sfHeader = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            })
            {
                g.DrawString(headerText, headerFont, headerTextBrush,
                    new Rectangle(rect.X, rect.Y, rect.Width, headerH), sfHeader);
            }

            // V16.7：正数表有 7 行，负数表只有 4 个指标。
            // 两边必须使用同一行高，所以统一按 7 行划分；负数表剩余 3 行保持空白。
            const int rowCount = 7;
            int contentTop = rect.Y + headerH;
            int contentH = Math.Max(1, rect.Height - headerH);
            float rowH = contentH / (float)rowCount;

            // 图标本身已经带 AN+/LX+/... 文字；只保留图标列 + 数值列。
            int iconColW = Math.Max(104, Math.Min((int)(rect.Width * 0.58f), rect.Width - 78));
            int splitX = rect.X + iconColW;
            g.DrawLine(borderPen, splitX, contentTop, splitX, rect.Bottom);

            using (var sfValue = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Trimming = StringTrimming.EllipsisCharacter
            })
            {
                for (int i = 0; i < rowCount; i++)
                {
                    int y1 = contentTop + (int)Math.Round(i * rowH);
                    int y2 = i == rowCount - 1
                        ? rect.Bottom
                        : contentTop + (int)Math.Round((i + 1) * rowH);

                    g.DrawLine(borderPen, rect.X, y1, rect.Right, y1);

                    var iconCell = new Rectangle(rect.X + 4, y1 + 2,
                        Math.Max(1, iconColW - 8), Math.Max(1, y2 - y1 - 4));
                    var valueRect = new Rectangle(splitX + 2, y1 + 1,
                        Math.Max(1, rect.Right - splitX - 4), Math.Max(1, y2 - y1 - 2));

                    if (i < metrics.Length && i < values.Length)
                    {
                        DrawMetricIcon(g, metrics[i], iconCell);

                        // 数值超过对应一级阈值时，只把“结果数值”显示为红色；
                        // 不改变白色表格背景，避免现场界面出现过多颜色。
                        double? value = values[i];
                        string text = value.HasValue ? value.Value.ToString("0.00") : "--";
                        bool alarm = value.HasValue && IsOverGrade1(metrics[i], value.Value);

                        g.DrawString(text, alarm ? alarmValueFont : valueFont,
                            alarm ? alarmValueBrush : valueBrush, valueRect, sfValue);
                    }
                }
            }
        }

        /// <summary>
        /// 判断某个结果是否超过一级阈值。
        /// 正负结果均按绝对值比较，例如 AN-=-0.59 与阈值 0.40 比较时按 0.59 判断。
        /// </summary>
        private bool IsOverGrade1(string metric, double value)
        {
            double threshold;
            if (!_grade1Thresholds.TryGetValue(metric, out threshold))
                return false;

            return Math.Abs(value) > threshold;
        }

        /// <summary>按原始宽高比把指标 PNG 图标居中绘制到单元格。</summary>
        private void DrawMetricIcon(Graphics g, string metric, Rectangle cell)
        {
            var img = GetIcon(metric);
            if (img == null || cell.Width <= 1 || cell.Height <= 1)
                return;

            float sx = cell.Width / (float)img.Width;
            float sy = cell.Height / (float)img.Height;
            float scale = Math.Min(sx, sy);
            int w = Math.Max(1, (int)Math.Round(img.Width * scale));
            int h = Math.Max(1, (int)Math.Round(img.Height * scale));
            int x = cell.X + (cell.Width - w) / 2;
            int y = cell.Y + (cell.Height - h) / 2;

            g.InterpolationMode = InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.DrawImage(img, new Rectangle(x, y, w, h));
        }

        /// <summary>从输出目录 Icons 文件夹加载并缓存指标图标。</summary>
        private Image GetIcon(string metric)
        {
            Image img;
            if (_iconCache.TryGetValue(metric, out img))
                return img;

            string[] candidates =
            {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Icons", metric + ".png"),
                Path.Combine(Application.StartupPath, "Icons", metric + ".png"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, metric + ".png")
            };

            for (int i = 0; i < candidates.Length; i++)
            {
                if (!File.Exists(candidates[i]))
                    continue;

                using (var fs = new FileStream(candidates[i], FileMode.Open, FileAccess.Read))
                using (var temp = Image.FromStream(fs))
                {
                    img = new Bitmap(temp);
                }
                _iconCache[metric] = img;
                return img;
            }

            _iconCache[metric] = null;
            return null;
        }
    }
}
