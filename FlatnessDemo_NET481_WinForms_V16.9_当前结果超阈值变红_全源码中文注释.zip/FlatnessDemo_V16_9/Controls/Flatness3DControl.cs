﻿// ============================================================================
// 文件：Flatness3DControl.cs
// 作用：把二维高度矩阵转换成工程型三维高度场，并用 WinForms + GDI+ 绘制。
// 组成：XYZ 网格、Surface Quad、四周 Curtain、BoundingBox、坐标轴、正/侧 Camera。
// 关键：显示时可夸张 Z，但 Max/Min/Avg 和算法原始值始终保持真实 mm。
// ============================================================================
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace FlatnessDemo.Controls
{
    /// <summary>
    /// V16.1 工程型三维高度场（放大显示优化）。
    ///
    /// 核心原则：
    /// 1. HeightMap 先进入真实 XYZ 世界坐标；X=宽度，Y=长度，Z=测量高度。
    /// 2. 正面/侧面共用同一个三维模型，只切换 Camera，不再维护两套固定 2D 模板。
    /// 3. 顶面使用连续 Quad Mesh；四周 Curtain/Skirt 的顶部直接使用真实边界 Z 数据。
    /// 4. Surface、Curtain、BoundingBox、底部网格和坐标轴全部走同一个 3D 投影。
    /// 5. Z 只做“显示夸张”，不改变 Max/Min 等真实算法数值。
    ///
    /// 该实现仍然只依赖 WinForms + GDI+，不引入 OpenGL/DirectX。
    /// </summary>
    public sealed class Flatness3DControl : UserControl
    {
        /// <summary>可切换的观察方向；同一模型只切换 Camera。</summary>
        private enum ViewMode
        {
            Front,
            Side
        }

        /// <summary>用于深度排序时区分顶面和四个封底侧面。</summary>
        private enum FaceKind
        {
            Surface,
            FrontSkirt,
            BackSkirt,
            LeftSkirt,
            RightSkirt
        }

        /// <summary>三维世界坐标点/向量。</summary>
        private struct Vec3
        {
            public double X;
            public double Y;
            public double Z;

            public Vec3(double x, double y, double z)
            {
                X = x;
                Y = y;
                Z = z;
            }
        }

        /// <summary>Camera 投影后的未缩放二维坐标及深度。</summary>
        private struct RawProjection
        {
            public double X;
            public double Y;
            public double Depth;

            public RawProjection(double x, double y, double depth)
            {
                X = x;
                Y = y;
                Depth = depth;
            }
        }

        /// <summary>简化三维相机：位置、三个正交方向和焦距。</summary>
        private sealed class Camera3D
        {
            public Vec3 Position;
            public Vec3 Right;
            public Vec3 Up;
            public Vec3 Forward;
            public double FocalLength;
        }

        /// <summary>把 Camera 投影结果缩放/平移到控件像素坐标。</summary>
        private sealed class RenderTransform
        {
            private readonly Camera3D _camera;
            private readonly double _scale;
            private readonly double _offsetX;
            private readonly double _offsetY;

            public RenderTransform(
                Camera3D camera,
                double scale,
                double offsetX,
                double offsetY)
            {
                _camera = camera;
                _scale = scale;
                _offsetX = offsetX;
                _offsetY = offsetY;
            }

            /// <summary>把世界坐标点投影到最终控件像素坐标。</summary>
            public PointF Project(Vec3 point)
            {
                RawProjection raw = ProjectRaw(_camera, point);

                return new PointF(
                    (float)(raw.X * _scale + _offsetX),
                    (float)(raw.Y * _scale + _offsetY));
            }

            /// <summary>返回点在相机方向上的深度，用于面片遮挡排序。</summary>
            public double Depth(Vec3 point)
            {
                return ProjectRaw(_camera, point).Depth;
            }
        }

        /// <summary>需要参与画家算法排序的一个四边形面片。</summary>
        private sealed class Face3D
        {
            public Vec3[] Points;
            public FaceKind Kind;
            public int BandIndex;
            public double Depth;
        }

        // 右上角“正面/侧面”切换按钮。
        private readonly Button _viewButton;

        // 原始高度矩阵。正式项目可直接传入 11×N 或 N×11 数据。
        private double[,] _source = new double[5, 5];
        private ViewMode _viewMode = ViewMode.Front;

        // 实际瓷砖尺寸用于构造 XYZ 世界坐标比例。
        private double _tileLengthMm = 1200.0;
        private double _tileWidthMm = 600.0;

        /// <summary>
        /// 仅用于显示高度夸张。17 为 V16 默认视觉倍率基准。
        /// 真实数值、Max/Min 和算法结果完全不受影响。
        /// </summary>
        public float HeightScale { get; set; } = 17f;

        /// <summary>
        /// 初始化绘图控件、视角按钮和默认相机状态。
        /// </summary>
        public Flatness3DControl()
        {
            DoubleBuffered = true;
            ResizeRedraw = true;
            BackColor = Theme.Panel;
            ForeColor = Theme.Text;
            MinimumSize = new Size(440, 270);

            _viewButton = Theme.Button("侧面");
            _viewButton.Size = new Size(70, 27);
            _viewButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _viewButton.BackColor = Theme.Panel2;
            _viewButton.FlatAppearance.BorderColor = Theme.Border;

            _viewButton.Click += delegate
            {
                _viewMode = _viewMode == ViewMode.Front
                    ? ViewMode.Side
                    : ViewMode.Front;

                _viewButton.Text = _viewMode == ViewMode.Front
                    ? "侧面"
                    : "正面";

                Invalidate();
            };

            Controls.Add(_viewButton);
            Resize += delegate { PositionButton(); };
            PositionButton();
        }

        /// <summary>
        /// 设置新的高度矩阵并触发重绘。
        /// </summary>
        public void SetSurface(double[,] values)
        {
            _source = values ?? new double[5, 5];
            Invalidate();
        }

        /// <summary>
        /// 设置真实瓷砖长度/宽度，影响 X/Y 世界坐标比例。
        /// </summary>
        public void SetTileSize(double lengthMm, double widthMm)
        {
            if (lengthMm > 0)
                _tileLengthMm = lengthMm;

            if (widthMm > 0)
                _tileWidthMm = widthMm;

            Invalidate();
        }

        /// <summary>
        /// 把视角切换按钮固定在控件右上角。
        /// </summary>
        private void PositionButton()
        {
            _viewButton.Location = new Point(
                Math.Max(4, ClientSize.Width - _viewButton.Width - 10),
                7);
        }

        /// <summary>
        /// WinForms 绘制入口：准备画布、数据统计并调用三维高度场绘制流程。
        /// </summary>
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            g.PixelOffsetMode = PixelOffsetMode.HighQuality;
            g.CompositingQuality = CompositingQuality.HighQuality;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            using (var titleFont = Theme.Font(10.8f, FontStyle.Bold))
            using (var infoFont = Theme.Font(8.0f))
            using (var axisFont = Theme.Font(7.0f))
            using (var axisTitleFont = Theme.Font(7.6f, FontStyle.Bold))
            {
                g.DrawString(
                    "3D 平整度图",
                    titleFont,
                    Brushes.WhiteSmoke,
                    12,
                    8);

                if (ClientSize.Width < 120 || ClientSize.Height < 100)
                    return;

                // 真实产线通常是 11×N 或 N×11。V16 自动把“短的传感器维”放到 X/宽度，
                // 把“长的时间采样维”放到 Y/长度；5×5 Demo 保持原方向。
                double[,] orientedSource = NormalizeHeightMapOrientation(_source);

                int outRows = GetDisplayRows(orientedSource);
                int outCols = GetDisplayColumns(orientedSource);

                double[,] z = ResampleForDisplay(orientedSource, outRows, outCols);

                double min;
                double max;
                double mean;
                // 数值统计始终来自原始测量值；插值/轻微平滑只服务于显示。
                GetStatistics(orientedSource, out min, out max, out mean);

                DrawHeightField(
                    g,
                    z,
                    min,
                    max,
                    mean,
                    infoFont,
                    axisFont,
                    axisTitleFont);
            }
        }

        /// <summary>
        /// 根据输入矩阵方向返回显示使用的 Y/长度方向采样行数。
        /// </summary>
        private static int GetDisplayRows(double[,] source)
        {
            int srcRows = source == null ? 0 : source.GetLength(0);

            // Y/长度方向保留较多网格，参考工程软件的密集测线效果。
            return ClampInt(Math.Max(srcRows, 33), 24, 55);
        }

        /// <summary>
        /// 根据输入矩阵方向返回显示使用的 X/宽度方向采样列数。
        /// </summary>
        private static int GetDisplayColumns(double[,] source)
        {
            int srcCols = source == null ? 0 : source.GetLength(1);

            // X/宽度方向同样形成完整 Mesh，而不是 V15 的少量纵线。
            return ClampInt(Math.Max(srcCols, 25), 18, 45);
        }

        /// <summary>
        /// 自动识别 11×N / N×11 方向，统一成“行=长度采样、列=宽度传感器”。
        /// </summary>
        private static double[,] NormalizeHeightMapOrientation(double[,] source)
        {
            if (source == null)
                return new double[1, 1];

            int rows = source.GetLength(0);
            int cols = source.GetLength(1);

            // 典型实机：5/7/9/11/16 个传感器 × 150~几百个时间采样点。
            // 如果“行”明显是短的传感器维，而“列”是长采样维，则转成 [Y采样, X传感器]。
            bool rowsLookLikeSensors = rows >= 5 && rows <= 20;
            bool columnsLookLikeSamples = cols >= 24 && cols >= rows * 2;

            if (!rowsLookLikeSensors || !columnsLookLikeSamples)
                return source;

            var transposed = new double[cols, rows];

            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                    transposed[c, r] = source[r, c];
            }

            return transposed;
        }

        /// <summary>
        /// 绘制完整三维场景：网格、面片、封底、坐标、包围框和信息栏。
        /// </summary>
        private void DrawHeightField(
            Graphics g,
            double[,] z,
            double min,
            double max,
            double mean,
            Font infoFont,
            Font axisFont,
            Font axisTitleFont)
        {
            int rows = z.GetLength(0);
            int cols = z.GetLength(1);

            double widthMm = Math.Max(1.0, _tileWidthMm);
            double lengthMm = Math.Max(1.0, _tileLengthMm);
            double shortSide = Math.Max(1.0, Math.Min(widthMm, lengthMm));

            double range = Math.Max(0.0, max - min);
            double visualMultiplier = HeightScale <= 0f
                ? 1.0
                : HeightScale / 17.0;

            visualMultiplier = Clamp(visualMultiplier, 0.35, 3.0);

            // 让 Z 的可见起伏约占短边 18%，同时避免极小噪声被无限放大。
            double desiredSurfaceSpan = shortSide * 0.18 * visualMultiplier;
            double safeRange = Math.Max(range, 0.05);
            double zVisualScale = range < 0.0000001
                ? 0.0
                : desiredSurfaceSpan / safeRange;

            double centerValue = (min + max) * 0.5;
            double minVisualZ = (min - centerValue) * zVisualScale;
            double maxVisualZ = (max - centerValue) * zVisualScale;

            // Curtain 是高度场封到底面的“垂幕”，不是瓷砖真实厚度。
            double curtainHeight = shortSide * 0.34;
            double zBase = minVisualZ - curtainHeight;
            double zFrameTop = maxVisualZ + shortSide * 0.42;

            double xMin = -widthMm * 0.5;
            double xMax = widthMm * 0.5;
            double yFront = -lengthMm * 0.5;
            double yBack = lengthMm * 0.5;

            Vec3[,] mesh = BuildMesh(
                z,
                centerValue,
                zVisualScale,
                xMin,
                xMax,
                yFront,
                yBack);

            // 底部坐标平面向观察者方向和左侧略微延伸，仍属于同一 XYZ 世界。
            double axisMarginX = widthMm * 0.10;
            double axisMarginY = lengthMm * 0.16;
            double groundXMin = xMin - axisMarginX;
            double groundXMax = xMax;
            double groundYFront = yFront - axisMarginY;
            double groundYBack = yBack;

            Vec3 target = new Vec3(
                0.0,
                0.0,
                zBase + (0.58 * (maxVisualZ - zBase)));

            Camera3D camera = CreateCamera(
                _viewMode,
                widthMm,
                lengthMm,
                zFrameTop - zBase,
                target);

            List<Vec3> fitPoints = BuildFitPoints(
                mesh,
                groundXMin,
                groundXMax,
                groundYFront,
                groundYBack,
                xMin,
                xMax,
                yFront,
                yBack,
                zBase,
                zFrameTop);

            // V16.1：尽量把三维图铺满可用区域。
            // 仍给标题、Y轴刻度和底部状态文字预留必要空间，避免 V16 出现“图形正确但缩在中间”的问题。
            RectangleF viewport = new RectangleF(
                34f,
                34f,
                Math.Max(80f, ClientSize.Width - 58f),
                Math.Max(80f, ClientSize.Height - 104f));

            RenderTransform transform = CreateRenderTransform(
                camera,
                fitPoints,
                viewport);

            using (var framePen = new Pen(Color.FromArgb(86, 133, 151), 0.85f))
            using (var gridPen = new Pen(Color.FromArgb(72, 118, 135), 0.72f))
            using (var axisPen = new Pen(Color.FromArgb(166, 190, 201), 0.95f))
            using (var meshPen = new Pen(Color.FromArgb(132, 210, 215), 0.68f))
            using (var meshMajorPen = new Pen(Color.FromArgb(174, 225, 227), 0.92f))
            using (var boundaryPen = new Pen(Color.FromArgb(37, 93, 104), 1.12f))
            {
                // 1. 同一 3D 世界中的底部网格和空间框，先画在后面。
                DrawGroundGrid(
                    g,
                    transform,
                    gridPen,
                    axisPen,
                    axisFont,
                    axisTitleFont,
                    xMin,
                    xMax,
                    yFront,
                    yBack,
                    groundXMin,
                    groundYFront,
                    zBase);

                DrawBoundingBox(
                    g,
                    transform,
                    framePen,
                    xMin,
                    xMax,
                    yFront,
                    yBack,
                    zBase,
                    zFrameTop);

                // 2. Surface + 四周 Skirt 一起按深度排序，避免 V15 的硬裁三角形。
                List<Face3D> faces = BuildFaces(mesh, zBase);
                UpdateFaceDepths(faces, transform);
                faces.Sort(CompareFacesFarToNear);
                DrawFaces(g, transform, faces);

                // 3. 双方向密集 Mesh。边界线来自真实 Z 数据，因此会自然弯曲。
                DrawSurfaceMesh(
                    g,
                    transform,
                    mesh,
                    meshPen,
                    meshMajorPen,
                    boundaryPen);

                // 4. 再强化靠近观察者的底部轴线，让刻度清楚但不脱离 3D 空间。
                DrawAxisBaselines(
                    g,
                    transform,
                    axisPen,
                    groundXMin,
                    xMax,
                    groundYFront,
                    yBack,
                    zBase);
            }

            DrawInfo(g, infoFont, min, max, mean);
        }

        /// <summary>
        /// 把二维高度矩阵转换为真实 X/Y 和视觉夸张 Z 的三维顶点网格。
        /// </summary>
        private static Vec3[,] BuildMesh(
            double[,] z,
            double centerValue,
            double zVisualScale,
            double xMin,
            double xMax,
            double yFront,
            double yBack)
        {
            int rows = z.GetLength(0);
            int cols = z.GetLength(1);
            var mesh = new Vec3[rows, cols];

            for (int r = 0; r < rows; r++)
            {
                // row 0 = 后边，最后一行 = 前边。
                double tr = r / (double)Math.Max(1, rows - 1);
                double y = yBack + (yFront - yBack) * tr;

                for (int c = 0; c < cols; c++)
                {
                    double tc = c / (double)Math.Max(1, cols - 1);
                    double x = xMin + (xMax - xMin) * tc;
                    double zz = (z[r, c] - centerValue) * zVisualScale;

                    mesh[r, c] = new Vec3(x, y, zz);
                }
            }

            return mesh;
        }

        /// <summary>
        /// 根据视角模式和场景中心构造 Camera 的位置与正交坐标轴。
        /// </summary>
        private static Camera3D CreateCamera(
            ViewMode mode,
            double widthMm,
            double lengthMm,
            double zSpan,
            Vec3 target)
        {
            double xyDiagonal = Math.Sqrt(widthMm * widthMm + lengthMm * lengthMm);
            double radius = Math.Max(1.0, xyDiagonal * 2.35 + zSpan * 0.55);

            // 正面仍保留 Y 深度；侧面只改变相机方位角，不改变模型。
            double azimuthDeg = mode == ViewMode.Front ? 0.0 : 34.0;

            // V16.1：降低俯视角，让 1200mm 的 Y 深度少占屏幕竖向空间，
            // 从而在保持完整模型的前提下把 600mm 宽度明显放大。
            // 正面尤其接近参考软件“宽、大、低视角”的工程曲面效果。
            double elevationDeg = mode == ViewMode.Front ? 12.0 : 19.0;

            double azimuth = azimuthDeg * Math.PI / 180.0;
            double elevation = elevationDeg * Math.PI / 180.0;

            double horizontal = radius * Math.Cos(elevation);

            Vec3 position = new Vec3(
                target.X + horizontal * Math.Sin(azimuth),
                target.Y - horizontal * Math.Cos(azimuth),
                target.Z + radius * Math.Sin(elevation));

            Vec3 forward = Normalize(Subtract(target, position));
            Vec3 worldUp = new Vec3(0.0, 0.0, 1.0);
            Vec3 right = Normalize(Cross(forward, worldUp));
            Vec3 up = Normalize(Cross(right, forward));

            return new Camera3D
            {
                Position = position,
                Forward = forward,
                Right = right,
                Up = up,
                FocalLength = radius * 0.92
            };
        }

        /// <summary>
        /// 把一个世界坐标点变换到 Camera 坐标并执行透视投影。
        /// </summary>
        private static RawProjection ProjectRaw(Camera3D camera, Vec3 point)
        {
            Vec3 relative = Subtract(point, camera.Position);

            double cameraX = Dot(relative, camera.Right);
            double cameraY = Dot(relative, camera.Up);
            double depth = Dot(relative, camera.Forward);

            depth = Math.Max(depth, 0.0001);

            double perspective = camera.FocalLength / depth;

            return new RawProjection(
                cameraX * perspective,
                -cameraY * perspective,
                depth);
        }

        /// <summary>
        /// 根据所有待显示点自动 Fit 到目标绘图区，生成屏幕缩放和平移参数。
        /// </summary>
        private static RenderTransform CreateRenderTransform(
            Camera3D camera,
            IList<Vec3> fitPoints,
            RectangleF viewport)
        {
            double minX = double.MaxValue;
            double maxX = double.MinValue;
            double minY = double.MaxValue;
            double maxY = double.MinValue;

            for (int i = 0; i < fitPoints.Count; i++)
            {
                RawProjection p = ProjectRaw(camera, fitPoints[i]);
                minX = Math.Min(minX, p.X);
                maxX = Math.Max(maxX, p.X);
                minY = Math.Min(minY, p.Y);
                maxY = Math.Max(maxY, p.Y);
            }

            if (minX == double.MaxValue || minY == double.MaxValue)
            {
                minX = -1.0;
                maxX = 1.0;
                minY = -1.0;
                maxY = 1.0;
            }

            double rawWidth = Math.Max(0.0001, maxX - minX);
            double rawHeight = Math.Max(0.0001, maxY - minY);

            double scale = Math.Min(
                viewport.Width / rawWidth,
                viewport.Height / rawHeight);

            // V16.1：只保留很小的安全边距，主体尽量占满面板。
            scale *= 0.985;

            double rawCenterX = (minX + maxX) * 0.5;
            double rawCenterY = (minY + maxY) * 0.5;
            double screenCenterX = viewport.Left + viewport.Width * 0.5;
            double screenCenterY = viewport.Top + viewport.Height * 0.5;

            return new RenderTransform(
                camera,
                scale,
                screenCenterX - rawCenterX * scale,
                screenCenterY - rawCenterY * scale);
        }

        /// <summary>
        /// 收集 Surface、底面和包围框关键点，确保自动 Fit 不裁切任何重要元素。
        /// </summary>
        private static List<Vec3> BuildFitPoints(
            Vec3[,] mesh,
            double groundXMin,
            double groundXMax,
            double groundYFront,
            double groundYBack,
            double frameXMin,
            double frameXMax,
            double frameYFront,
            double frameYBack,
            double zBase,
            double zFrameTop)
        {
            var result = new List<Vec3>();

            int rows = mesh.GetLength(0);
            int cols = mesh.GetLength(1);

            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                    result.Add(mesh[r, c]);
            }

            result.Add(new Vec3(groundXMin, groundYFront, zBase));
            result.Add(new Vec3(groundXMax, groundYFront, zBase));
            result.Add(new Vec3(groundXMin, groundYBack, zBase));
            result.Add(new Vec3(groundXMax, groundYBack, zBase));

            result.Add(new Vec3(frameXMin, frameYFront, zFrameTop));
            result.Add(new Vec3(frameXMax, frameYFront, zFrameTop));
            result.Add(new Vec3(frameXMin, frameYBack, zFrameTop));
            result.Add(new Vec3(frameXMax, frameYBack, zFrameTop));

            return result;
        }

        /// <summary>
        /// 从顶点网格生成顶面 Quad 和四周 Curtain 面片。
        /// </summary>
        private static List<Face3D> BuildFaces(Vec3[,] mesh, double zBase)
        {
            int rows = mesh.GetLength(0);
            int cols = mesh.GetLength(1);
            var faces = new List<Face3D>((rows - 1) * (cols - 1) + rows * 2 + cols * 2);

            for (int r = 0; r < rows - 1; r++)
            {
                for (int c = 0; c < cols - 1; c++)
                {
                    faces.Add(new Face3D
                    {
                        Kind = FaceKind.Surface,
                        BandIndex = r,
                        Points = new[]
                        {
                            mesh[r, c],
                            mesh[r, c + 1],
                            mesh[r + 1, c + 1],
                            mesh[r + 1, c]
                        }
                    });
                }
            }

            // 后边：row 0
            for (int c = 0; c < cols - 1; c++)
            {
                Vec3 a = mesh[0, c];
                Vec3 b = mesh[0, c + 1];
                faces.Add(CreateSkirtFace(a, b, zBase, FaceKind.BackSkirt, c));
            }

            // 前边：最后一行
            for (int c = 0; c < cols - 1; c++)
            {
                Vec3 a = mesh[rows - 1, c];
                Vec3 b = mesh[rows - 1, c + 1];
                faces.Add(CreateSkirtFace(a, b, zBase, FaceKind.FrontSkirt, c));
            }

            // 左边：col 0
            for (int r = 0; r < rows - 1; r++)
            {
                Vec3 a = mesh[r, 0];
                Vec3 b = mesh[r + 1, 0];
                faces.Add(CreateSkirtFace(a, b, zBase, FaceKind.LeftSkirt, r));
            }

            // 右边：最后一列
            for (int r = 0; r < rows - 1; r++)
            {
                Vec3 a = mesh[r, cols - 1];
                Vec3 b = mesh[r + 1, cols - 1];
                faces.Add(CreateSkirtFace(a, b, zBase, FaceKind.RightSkirt, r));
            }

            return faces;
        }

        /// <summary>
        /// 生成一块边界封底面，使侧壁顶部严格跟随真实边缘 Z 曲线。
        /// </summary>
        private static Face3D CreateSkirtFace(
            Vec3 a,
            Vec3 b,
            double zBase,
            FaceKind kind,
            int bandIndex)
        {
            Vec3 aBase = new Vec3(a.X, a.Y, zBase);
            Vec3 bBase = new Vec3(b.X, b.Y, zBase);

            return new Face3D
            {
                Kind = kind,
                BandIndex = bandIndex,
                Points = new[] { a, b, bBase, aBase }
            };
        }

        /// <summary>
        /// 计算每个面片的平均深度，为画家算法排序提供依据。
        /// </summary>
        private static void UpdateFaceDepths(
            IList<Face3D> faces,
            RenderTransform transform)
        {
            for (int i = 0; i < faces.Count; i++)
            {
                Face3D face = faces[i];
                double sum = 0.0;

                for (int p = 0; p < face.Points.Length; p++)
                    sum += transform.Depth(face.Points[p]);

                face.Depth = sum / Math.Max(1, face.Points.Length);
            }
        }

        /// <summary>
        /// 按深度从远到近排序面片。
        /// </summary>
        private static int CompareFacesFarToNear(Face3D a, Face3D b)
        {
            // Depth 越大越远，先画远处，再画近处。
            return b.Depth.CompareTo(a.Depth);
        }

        /// <summary>
        /// 按排序结果填充 Surface/Curtain 面片，解决大部分遮挡关系。
        /// </summary>
        private static void DrawFaces(
            Graphics g,
            RenderTransform transform,
            IList<Face3D> faces)
        {
            Color surfaceA = Color.FromArgb(246, 22, 190, 199);
            Color surfaceB = Color.FromArgb(246, 35, 205, 210);
            Color front = Color.FromArgb(248, 17, 194, 200);
            Color back = Color.FromArgb(246, 12, 168, 181);
            Color left = Color.FromArgb(247, 14, 178, 190);
            Color right = Color.FromArgb(247, 8, 160, 178);

            for (int i = 0; i < faces.Count; i++)
            {
                Face3D face = faces[i];
                PointF[] polygon = ProjectPolygon(transform, face.Points);
                Color fill;

                switch (face.Kind)
                {
                    case FaceKind.Surface:
                        fill = (face.BandIndex % 2 == 0) ? surfaceA : surfaceB;
                        break;
                    case FaceKind.FrontSkirt:
                        fill = front;
                        break;
                    case FaceKind.BackSkirt:
                        fill = back;
                        break;
                    case FaceKind.LeftSkirt:
                        fill = left;
                        break;
                    default:
                        fill = right;
                        break;
                }

                using (var brush = new SolidBrush(fill))
                {
                    g.FillPolygon(brush, polygon);
                }

            }
        }

        /// <summary>
        /// 在已填充曲面上绘制 X/Y 双方向网格线。
        /// </summary>
        private static void DrawSurfaceMesh(
            Graphics g,
            RenderTransform transform,
            Vec3[,] mesh,
            Pen normalPen,
            Pen majorPen,
            Pen boundaryPen)
        {
            int rows = mesh.GetLength(0);
            int cols = mesh.GetLength(1);

            for (int r = 0; r < rows; r++)
            {
                PointF[] line = new PointF[cols];
                for (int c = 0; c < cols; c++)
                    line[c] = transform.Project(mesh[r, c]);

                Pen pen = (r == 0 || r == rows - 1)
                    ? boundaryPen
                    : (r % 5 == 0 ? majorPen : normalPen);

                if (line.Length >= 2)
                    g.DrawLines(pen, line);
            }

            for (int c = 0; c < cols; c++)
            {
                PointF[] line = new PointF[rows];
                for (int r = 0; r < rows; r++)
                    line[r] = transform.Project(mesh[r, c]);

                Pen pen = (c == 0 || c == cols - 1)
                    ? boundaryPen
                    : (c % 5 == 0 ? majorPen : normalPen);

                if (line.Length >= 2)
                    g.DrawLines(pen, line);
            }
        }

        /// <summary>
        /// 绘制 ZBase 底部参考网格，增强三维空间感。
        /// </summary>
        private static void DrawGroundGrid(
            Graphics g,
            RenderTransform transform,
            Pen gridPen,
            Pen axisPen,
            Font axisFont,
            Font axisTitleFont,
            double xMin,
            double xMax,
            double yFront,
            double yBack,
            double groundXMin,
            double groundYFront,
            double zBase)
        {
            const int xTicks = 5;
            const int yTicks = 5;

            // X 等值网格：沿 Y 方向延伸。
            for (int i = 0; i <= xTicks; i++)
            {
                double t = i / (double)xTicks;
                double x = xMin + (xMax - xMin) * t;

                DrawWorldLine(
                    g,
                    transform,
                    gridPen,
                    new Vec3(x, groundYFront, zBase),
                    new Vec3(x, yBack, zBase));
            }

            // Y 等值网格：沿 X 方向延伸。
            for (int i = 0; i <= yTicks; i++)
            {
                double t = i / (double)yTicks;
                double y = yFront + (yBack - yFront) * t;

                DrawWorldLine(
                    g,
                    transform,
                    gridPen,
                    new Vec3(groundXMin, y, zBase),
                    new Vec3(xMax, y, zBase));
            }

            // 前方额外基线，形成参考软件那种位于 Surface 下方的同一坐标平面。
            DrawWorldLine(
                g,
                transform,
                axisPen,
                new Vec3(groundXMin, groundYFront, zBase),
                new Vec3(xMax, groundYFront, zBase));

            DrawWorldLine(
                g,
                transform,
                axisPen,
                new Vec3(groundXMin, groundYFront, zBase),
                new Vec3(groundXMin, yBack, zBase));

            DrawXAxisLabels(
                g,
                transform,
                axisPen,
                axisFont,
                axisTitleFont,
                xMin,
                xMax,
                groundYFront,
                zBase,
                xTicks);

            DrawYAxisLabels(
                g,
                transform,
                axisPen,
                axisFont,
                axisTitleFont,
                groundXMin,
                yFront,
                yBack,
                zBase,
                yTicks);
        }

        /// <summary>
        /// 绘制 X/宽度方向刻度和数值标签。
        /// </summary>
        private static void DrawXAxisLabels(
            Graphics g,
            RenderTransform transform,
            Pen axisPen,
            Font axisFont,
            Font axisTitleFont,
            double xMin,
            double xMax,
            double y,
            double zBase,
            int ticks)
        {
            for (int i = 0; i <= ticks; i++)
            {
                double t = i / (double)ticks;
                Vec3 world = new Vec3(xMin + (xMax - xMin) * t, y, zBase);
                PointF p = transform.Project(world);

                g.DrawLine(axisPen, p.X, p.Y, p.X, p.Y + 4f);

                string label = FormatAxisValue((xMax - xMin) * t);
                SizeF size = g.MeasureString(label, axisFont);
                g.DrawString(
                    label,
                    axisFont,
                    Brushes.LightGray,
                    p.X - size.Width * 0.5f,
                    p.Y + 5f);
            }

            PointF titlePoint = transform.Project(new Vec3(xMax, y, zBase));
            string title = "X / 宽度(mm)";
            SizeF titleSize = g.MeasureString(title, axisTitleFont);

            g.DrawString(
                title,
                axisTitleFont,
                Brushes.LightGray,
                titlePoint.X - titleSize.Width + 4f,
                titlePoint.Y + 20f);
        }

        /// <summary>
        /// 绘制 Y/长度方向刻度和数值标签。
        /// </summary>
        private static void DrawYAxisLabels(
            Graphics g,
            RenderTransform transform,
            Pen axisPen,
            Font axisFont,
            Font axisTitleFont,
            double x,
            double yFront,
            double yBack,
            double zBase,
            int ticks)
        {
            for (int i = 0; i <= ticks; i++)
            {
                double t = i / (double)ticks;
                Vec3 world = new Vec3(x, yFront + (yBack - yFront) * t, zBase);
                PointF p = transform.Project(world);

                g.DrawLine(axisPen, p.X - 3f, p.Y, p.X + 2f, p.Y);

                string label = FormatAxisValue((yBack - yFront) * t);
                SizeF size = g.MeasureString(label, axisFont);

                g.DrawString(
                    label,
                    axisFont,
                    Brushes.LightGray,
                    p.X - size.Width - 5f,
                    p.Y - size.Height * 0.5f);
            }

            PointF titlePoint = transform.Project(new Vec3(x, yBack, zBase));
            g.DrawString(
                "Y / 长度(mm)",
                axisTitleFont,
                Brushes.LightGray,
                titlePoint.X - 4f,
                titlePoint.Y - 18f);
        }

        /// <summary>
        /// 绘制 X/Y 轴基线和轴标题。
        /// </summary>
        private static void DrawAxisBaselines(
            Graphics g,
            RenderTransform transform,
            Pen axisPen,
            double xMin,
            double xMax,
            double yFront,
            double yBack,
            double zBase)
        {
            DrawWorldLine(
                g,
                transform,
                axisPen,
                new Vec3(xMin, yFront, zBase),
                new Vec3(xMax, yFront, zBase));

            DrawWorldLine(
                g,
                transform,
                axisPen,
                new Vec3(xMin, yFront, zBase),
                new Vec3(xMin, yBack, zBase));
        }

        /// <summary>
        /// 绘制三维包围框，明确整个 XYZ 测量空间。
        /// </summary>
        private static void DrawBoundingBox(
            Graphics g,
            RenderTransform transform,
            Pen pen,
            double xMin,
            double xMax,
            double yFront,
            double yBack,
            double zBase,
            double zTop)
        {
            Vec3 b00 = new Vec3(xMin, yFront, zBase);
            Vec3 b10 = new Vec3(xMax, yFront, zBase);
            Vec3 b01 = new Vec3(xMin, yBack, zBase);
            Vec3 b11 = new Vec3(xMax, yBack, zBase);

            Vec3 t00 = new Vec3(xMin, yFront, zTop);
            Vec3 t10 = new Vec3(xMax, yFront, zTop);
            Vec3 t01 = new Vec3(xMin, yBack, zTop);
            Vec3 t11 = new Vec3(xMax, yBack, zTop);

            // 底框
            DrawWorldLine(g, transform, pen, b00, b10);
            DrawWorldLine(g, transform, pen, b10, b11);
            DrawWorldLine(g, transform, pen, b11, b01);
            DrawWorldLine(g, transform, pen, b01, b00);

            // 顶框
            DrawWorldLine(g, transform, pen, t00, t10);
            DrawWorldLine(g, transform, pen, t10, t11);
            DrawWorldLine(g, transform, pen, t11, t01);
            DrawWorldLine(g, transform, pen, t01, t00);

            // 四根 Z 立柱
            DrawWorldLine(g, transform, pen, b00, t00);
            DrawWorldLine(g, transform, pen, b10, t10);
            DrawWorldLine(g, transform, pen, b01, t01);
            DrawWorldLine(g, transform, pen, b11, t11);
        }

        /// <summary>
        /// 在 3D 区底部独立显示视角、Max、Min、Avg，避免和坐标轴文字重叠。
        /// </summary>
        private void DrawInfo(
            Graphics g,
            Font font,
            double min,
            double max,
            double mean)
        {
            string view = _viewMode == ViewMode.Front ? "正面" : "侧面";
            string info =
                "视角：" + view +
                "    |    Max: " + max.ToString("0.00") + " mm" +
                "    |    Min: " + min.ToString("0.00") + " mm" +
                "    |    Avg: " + mean.ToString("0.00") + " mm";

            // V16.6：状态信息使用独立底栏，不再和 X 轴标题/刻度叠在一起。
            float bandH = 28f;
            float bandY = Math.Max(0f, Height - bandH - 2f);
            using (var bg = new SolidBrush(Color.FromArgb(20, 54, 82)))
            using (var border = new Pen(Color.FromArgb(49, 96, 128), 1f))
            using (var brush = new SolidBrush(Color.FromArgb(205, 218, 228)))
            using (var sf = new StringFormat
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center,
                Trimming = StringTrimming.EllipsisCharacter
            })
            {
                var rect = new RectangleF(8f, bandY, Math.Max(10f, Width - 16f), bandH);
                g.FillRectangle(bg, rect);
                g.DrawLine(border, rect.Left, rect.Top, rect.Right, rect.Top);
                g.DrawString(info, font, brush, rect, sf);
            }
        }

        /// <summary>
        /// 把三维多边形顶点批量投影为屏幕 PointF 数组。
        /// </summary>
        private static PointF[] ProjectPolygon(RenderTransform transform, Vec3[] points)
        {
            PointF[] result = new PointF[points.Length];
            for (int i = 0; i < points.Length; i++)
                result[i] = transform.Project(points[i]);
            return result;
        }

        /// <summary>
        /// 绘制一条由两个三维世界点定义的线段。
        /// </summary>
        private static void DrawWorldLine(
            Graphics g,
            RenderTransform transform,
            Pen pen,
            Vec3 a,
            Vec3 b)
        {
            g.DrawLine(pen, transform.Project(a), transform.Project(b));
        }

        /// <summary>
        /// 以适合坐标轴的格式输出毫米数值。
        /// </summary>
        private static string FormatAxisValue(double value)
        {
            if (Math.Abs(value - Math.Round(value)) < 0.01)
                return Math.Round(value).ToString("0");

            return value.ToString("0.0");
        }

        /// <summary>
        /// 统计高度矩阵的最小值、最大值和平均值，忽略非法数值。
        /// </summary>
        private static void GetStatistics(
            double[,] data,
            out double min,
            out double max,
            out double mean)
        {
            min = double.MaxValue;
            max = double.MinValue;
            double sum = 0.0;
            int count = 0;

            if (data == null || data.Length == 0)
            {
                min = 0.0;
                max = 0.0;
                mean = 0.0;
                return;
            }

            foreach (double value in data)
            {
                if (double.IsNaN(value) || double.IsInfinity(value))
                    continue;

                min = Math.Min(min, value);
                max = Math.Max(max, value);
                sum += value;
                count++;
            }

            if (count <= 0)
            {
                min = 0.0;
                max = 0.0;
                mean = 0.0;
                return;
            }

            mean = sum / count;
        }

        /// <summary>
        /// 把过密或过稀的高度矩阵重采样到适合实时显示的网格密度。
        /// </summary>
        private static double[,] ResampleForDisplay(
            double[,] src,
            int outRows,
            int outCols)
        {
            double[,] dense = InterpolateBilinear(src, outRows, outCols);

            // Demo 的 5x5 点很稀疏，做一次轻微平滑；真实 11xN / Nx11 数据不再重复模糊。
            int inRows = src == null ? 0 : src.GetLength(0);
            int inCols = src == null ? 0 : src.GetLength(1);

            if (inRows <= 7 && inCols <= 7)
                dense = Smooth(dense);

            return dense;
        }

        /// <summary>
        /// 对显示网格做轻量平滑，仅改善视觉连续性，不回写算法数据。
        /// </summary>
        private static double[,] Smooth(double[,] src)
        {
            int rows = src.GetLength(0);
            int cols = src.GetLength(1);
            var dst = new double[rows, cols];

            for (int r = 0; r < rows; r++)
            {
                for (int c = 0; c < cols; c++)
                {
                    double sum = 0.0;
                    double weight = 0.0;

                    for (int dr = -1; dr <= 1; dr++)
                    {
                        for (int dc = -1; dc <= 1; dc++)
                        {
                            int rr = ClampInt(r + dr, 0, rows - 1);
                            int cc = ClampInt(c + dc, 0, cols - 1);

                            double w = (dr == 0 && dc == 0)
                                ? 4.0
                                : (dr == 0 || dc == 0 ? 2.0 : 1.0);

                            sum += src[rr, cc] * w;
                            weight += w;
                        }
                    }

                    dst[r, c] = weight <= 0.0 ? src[r, c] : sum / weight;
                }
            }

            return dst;
        }

        /// <summary>
        /// 使用双线性插值把原始矩阵缩放到指定行列数。
        /// </summary>
        private static double[,] InterpolateBilinear(
            double[,] src,
            int outRows,
            int outCols)
        {
            var dst = new double[outRows, outCols];

            if (src == null)
                return dst;

            int inRows = src.GetLength(0);
            int inCols = src.GetLength(1);

            if (inRows <= 0 || inCols <= 0)
                return dst;

            for (int r = 0; r < outRows; r++)
            {
                double y = r * (inRows - 1.0) / Math.Max(1, outRows - 1);
                int y0 = (int)Math.Floor(y);
                int y1 = Math.Min(y0 + 1, inRows - 1);
                double fy = y - y0;

                for (int c = 0; c < outCols; c++)
                {
                    double x = c * (inCols - 1.0) / Math.Max(1, outCols - 1);
                    int x0 = (int)Math.Floor(x);
                    int x1 = Math.Min(x0 + 1, inCols - 1);
                    double fx = x - x0;

                    double v00 = Sanitize(src[y0, x0]);
                    double v01 = Sanitize(src[y0, x1]);
                    double v10 = Sanitize(src[y1, x0]);
                    double v11 = Sanitize(src[y1, x1]);

                    double a = v00 * (1.0 - fx) + v01 * fx;
                    double b = v10 * (1.0 - fx) + v11 * fx;

                    dst[r, c] = a * (1.0 - fy) + b * fy;
                }
            }

            return dst;
        }

        /// <summary>
        /// 过滤 NaN/Infinity，保证绘图计算不会传播非法数值。
        /// </summary>
        private static double Sanitize(double value)
        {
            return double.IsNaN(value) || double.IsInfinity(value) ? 0.0 : value;
        }

        /// <summary>
        /// 三维向量减法。
        /// </summary>
        private static Vec3 Subtract(Vec3 a, Vec3 b)
        {
            return new Vec3(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        }

        /// <summary>
        /// 三维向量点积。
        /// </summary>
        private static double Dot(Vec3 a, Vec3 b)
        {
            return a.X * b.X + a.Y * b.Y + a.Z * b.Z;
        }

        /// <summary>
        /// 三维向量叉积。
        /// </summary>
        private static Vec3 Cross(Vec3 a, Vec3 b)
        {
            return new Vec3(
                a.Y * b.Z - a.Z * b.Y,
                a.Z * b.X - a.X * b.Z,
                a.X * b.Y - a.Y * b.X);
        }

        /// <summary>
        /// 三维向量单位化。
        /// </summary>
        private static Vec3 Normalize(Vec3 value)
        {
            double length = Math.Sqrt(Dot(value, value));
            if (length < 0.0000001)
                return new Vec3(0.0, 0.0, 1.0);

            return new Vec3(
                value.X / length,
                value.Y / length,
                value.Z / length);
        }

        /// <summary>
        /// 把 double 限制在给定闭区间。
        /// </summary>
        private static double Clamp(double value, double min, double max)
        {
            return Math.Max(min, Math.Min(max, value));
        }

        /// <summary>
        /// 把 int 限制在给定闭区间。
        /// </summary>
        private static int ClampInt(int value, int min, int max)
        {
            return Math.Max(min, Math.Min(max, value));
        }
    }
}
