// ============================================================================
// 文件：FlatnessAlgorithms.cs
// 作用：实现当前 Demo 使用的 Planar 平整度指标计算，以及比例/补偿应用。
// 注意：本文件只做纯计算，不引用任何 WinForms 控件，便于后续单元测试和独立复用。
// ============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using FlatnessDemo.Models;

namespace FlatnessDemo.Algorithms
{
    /// <summary>
    /// Planar 平整度算法集合。
    /// </summary>
    public static class FlatnessAlgorithms
    {
        /// <summary>
        /// 根据命名测点计算 SVE、BAR、AN±、LX±、LY±、CE± 等指标。
        /// </summary>
        /// <param name="p">当前砖的命名测点。</param>
        /// <returns>未应用比例/补偿的原始算法结果。</returns>
        public static FlatnessResult Calculate(FlatnessInput p)
        {
            var result = new FlatnessResult();

            // SVE：当前 Demo 按四角组合差计算。
            result.SVE = (p["A"] + p["C"]) - (p["D"] + p["B"]);

            // LX：比较左右两条边中心相对于两端平均值的偏差。
            var lx = new[]
            {
                p["AB"] - (p["A"] + p["B"]) / 2.0,
                p["CD"] - (p["C"] + p["D"]) / 2.0
            };
            SplitPlusMinus(lx, out var lxPlus, out var lxMinus);
            result.LXPlus = lxPlus;
            result.LXMinus = lxMinus;

            // LY：比较上下两条边中心相对于两端平均值的偏差。
            var ly = new[]
            {
                p["DA"] - (p["D"] + p["A"]) / 2.0,
                p["BC"] - (p["B"] + p["C"]) / 2.0
            };
            SplitPlusMinus(ly, out var lyPlus, out var lyMinus);
            result.LYPlus = lyPlus;
            result.LYMinus = lyMinus;

            // CE：中心点分别相对两组对角角点平均值计算偏差。
            var ce = new[]
            {
                p["CE"] - (p["A"] + p["C"]) / 2.0,
                p["CE"] - (p["B"] + p["D"]) / 2.0
            };
            SplitPlusMinus(ce, out var cePlus, out var ceMinus);
            result.CEPlus = cePlus;
            result.CEMinus = ceMinus;

            // AN：四个角点分别与其三个相邻/内侧点做差，最后拆分正负极值。
            var an = new[]
            {
                p["A"] - p["A1"], p["A"] - p["A2"], p["A"] - p["A3"],
                p["B"] - p["B1"], p["B"] - p["B2"], p["B"] - p["B3"],
                p["C"] - p["C1"], p["C"] - p["C2"], p["C"] - p["C3"],
                p["D"] - p["D1"], p["D"] - p["D2"], p["D"] - p["D3"]
            };
            SplitPlusMinus(an, out var anPlus, out var anMinus);
            result.ANPlus = anPlus;
            result.ANMinus = anMinus;

            // BAR：
            // 分别比较四条边“边中心点”与它左右/上下相邻的两个点，共 8 个差值；
            // 对 8 个差值取绝对值后，再取最大值作为 BAR。
            // 上边：A1 ↔ DA ↔ D1
            // 左边：A2 ↔ AB ↔ B2
            // 右边：D2 ↔ CD ↔ C2
            // 下边：B1 ↔ BC ↔ C1
            var bar = new[]
            {
                Math.Abs(p["A1"] - p["DA"]),
                Math.Abs(p["DA"] - p["D1"]),
                Math.Abs(p["A2"] - p["AB"]),
                Math.Abs(p["AB"] - p["B2"]),
                Math.Abs(p["D2"] - p["CD"]),
                Math.Abs(p["CD"] - p["C2"]),
                Math.Abs(p["B1"] - p["BC"]),
                Math.Abs(p["BC"] - p["C1"])
            };
            result.BAR = bar.Max();

            // RUL 的最终业务公式目前还没有确认。
            // Demo 保持 0，界面结果表会显示 “--”，避免误认为是真实计算值。
            result.RUL = 0.0;

            return result;
        }

        /// <summary>
        /// 对原始算法结果逐指标应用比例和补偿：result = raw × Ratio + Offset。
        /// </summary>
        public static FlatnessResult ApplyCompensation(
            FlatnessResult raw,
            IEnumerable<CompensationItem> settings)
        {
            // 转成字典后可按指标名称 O(1) 查找配置。
            var map = settings.ToDictionary(x => x.Metric, StringComparer.OrdinalIgnoreCase);

            return new FlatnessResult
            {
                SVE = Apply("SVE", raw.SVE, map),
                BAR = Apply("BAR", raw.BAR, map),
                RUL = Apply("RUL", raw.RUL, map),
                ANPlus = Apply("AN+", raw.ANPlus, map),
                ANMinus = Apply("AN-", raw.ANMinus, map),
                LXPlus = Apply("LX+", raw.LXPlus, map),
                LXMinus = Apply("LX-", raw.LXMinus, map),
                LYPlus = Apply("LY+", raw.LYPlus, map),
                LYMinus = Apply("LY-", raw.LYMinus, map),
                CEPlus = Apply("CE+", raw.CEPlus, map),
                CEMinus = Apply("CE-", raw.CEMinus, map)
            };
        }

        /// <summary>
        /// 对单个指标应用比例/补偿；没有找到配置时原值直通。
        /// </summary>
        private static double Apply(
            string metric,
            double value,
            IDictionary<string, CompensationItem> map)
        {
            CompensationItem item;
            if (!map.TryGetValue(metric, out item))
                return value;

            return value * item.Ratio + item.Offset;
        }

        /// <summary>
        /// 从一组有正有负的偏差中提取：最大正值和最小负值。
        /// 如果没有正值/负值，对应结果返回 0。
        /// </summary>
        private static void SplitPlusMinus(
            IEnumerable<double> values,
            out double plus,
            out double minus)
        {
            var arr = values.ToArray();
            plus = arr.Where(x => x > 0).DefaultIfEmpty(0).Max();
            minus = arr.Where(x => x < 0).DefaultIfEmpty(0).Min();
        }
    }
}
